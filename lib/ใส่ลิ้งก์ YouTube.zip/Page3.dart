import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page3 extends StatefulWidget {
  Page3({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page3State createState() => _Page3State();
}

class _Page3State extends State<Page3> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

   void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/WKhiBs2QjyA?si=byvc6QcqeX-NGrTt'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTExMVFRUXGBcaFxcYGBUYFxcYFxgWGBcXGBgYHSggGB0lHRcXIjEhJSkrLi8uGCAzODMtNygtLisBCgoKDg0OGxAQGy0mICUvLS0tLi0tLS8rLS0tLS0tLS0wLSstLS8tLS0tLS0tLS01LS0vLS0tLS0tLS0tLS0tLf/AABEIAKgBKwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAADAQIEBQYABwj/xABBEAACAQIEAwUFBwEHBAIDAAABAhEAAwQSITEFQVEGEyJhcTKBkaGxFCNCUsHR8GIHM0NygpLhFVOy8STSFjSi/8QAGQEAAgMBAAAAAAAAAAAAAAAAAQMAAgQF/8QAMBEAAgEDAgMHAwQDAQAAAAAAAAECAxEhEjEEE2EyQVFxkaHwIrHRFIHB4QVCUhX/2gAMAwEAAhEDEQA/AJQFFWuVKIq1rEHAU8LShaeKgQRtUot0dVpQtQgALFPWnsBThp0qEGZaSKMKYRQIMNcKcaLhcO1xgAP+KNwpXBIhO2tS+0SCwqgaGJJGskfpWlwOBVBED+dTUPjuBW4wOh00H71nm3LYfCNnky2FxqXBKkHqOY9RUoGqDDcLK3S66HNG+kcga1l4gplO/luKYpFHTsRgKTLUbC4sZslwgE+yeTeXkanmKsUsAK00ijhaTLUIRstPiixTSahAbU0qKez00elQAMqK7JSstJNEguU1zClUzXFTQCBK0kCixTMtEAwrTWtUQimmiAAyUMqKlGmFKhCOK40UpSFahADUzIaklaYRUITAsedKFp4omWoQGE5U9V8qfbSiRUICAooSlUU8CgEF3ddlowWlCUCWAwaYUqZlphWoEi93rHWtTwnAhFjnz9aorIAYHoRWps3BFUmy8BHbnpA+f/FZ3iWMIPmT7hOp+laV7fw1rI8dxlsNEiQ2vyn5GqD4gMNbJGg2Os8yN6dwLitvVPj/AOzVPc4qT4Q3iyhvPMjEH4iKpHcreLLsfEB1B1I+tFsvKzJ3bdTbugqTqQRrtGvurU4S5mRW6qD8RWN7RObhXUmFETzEaT7tKm4LtNagKGAgR8KMHlmeorGoIpjOBvULDY8PEGZqZZuA767/ABpgoRjTYp0Vb8K4YHUk7kGPLzqspWRZRuyly9KeqVk8Vir+BxLpcYshP4pII6qa1lniFq4oZSCCOVVp1VNYL1KThuLkoZt60ZWmlbSmCgPdiuYCnNTXwzDUgjzNBtLcKTewxloTg8qKBrE0rKKIGRTb86aqmpOWkijcAFlpoojimUSDGphWn00VADSKYVopimRUITlp4qtwnH2usytgrlqD7ZIAI6wfpVjbxdgt3Yu5bkZsjABiOogmsseLpt2eB74edroMq0pFFTDsdYHuIJ+Apl+6qCXZUH9RA+tPU4y2Ypxa3QqinhaTDur6qwYeRBowt0QDVFOy09VritQIPLSZfjRgKGL6zA1Ply9TsKDaW5ZJvY4W6lWL5Tc+H6RQnuKupYGBsN/dMUy5xGxBBM+/9qq3ciwPxOOIWFM6Hn/mH7Vh+0N4u2wG2vkdPrWttYvDroLcj1J+po6XsP8A9i3t+VT9RVWrjVUsed4AEOSd/wD7AH6iuBgoT5/U/pXp1u/a5WkH+lf2oy3LZ3tp/tX9qGhk5nQ8e47xRbanxAsVCqJ8t/dWMtsetfSb4XDv7Vi0fW2h/Sod3szw5/awlifJFU/ERU0MrKdzzTsZfeRmJr0dsFZdREo0e0vP1HOjWey+DX2EKejH9ZqSnBY9i5p0IB+YpHEQm7OA6hUjG6kQ24eFTN3maPKKiYHjpRmjxKN45HlU/iPCbpQ7tA0RIlvKWIArz7/rGLsOwvYYorHRSpAA5ANsdKXThUdtTsvUZKdO305L7tGq4tDJAYaqTpB8zWN7O4h7d8LmBtsSB/mG8eVbCy1nE22BVlzCDBgigYPslh7bKwzMV9nMdvdWiFOUZ3EzqKUbFzb2mq4sHus5nYAa8htFWgIFPTgPeHQlIE+Z9JpXEw5ytF7F+HlyneS3B4GAdxPoKtb7LkOYyCCD8KzOH7wayD51X9oeO90pzvA5Abk+VYqNCSeTXUqIteGX85eBopCg9fCJ+c1NIrDcK7cWVQJkK/OT1q+wXaBLnsmuxTjaKRy6ktUmy2YCkJoSXZpxFXKCM9DZ6RkpIogEIobLFFK0zJRADJpDRCtJkqECXeJXhcVFwl24rbuoXIo9WImonFcRZtM111S0TCliApPIAk1aJ2huW0lrZvFVmLaNnaPyqs1ZYe+uLw6vdwxSdcl5VLCNjGsfWuDGOpHTbszOLwjO9rEd/c8ILBbbhbeXcksNSI3PP31W/amx2IzXUy4azMBpEjckk7kgSeg0o3HMccReGFslkJ0uMNgqn2Rygc+rabAVONtWH2c//q2RN65sGIg92fqx9B1ro0aXLjncyznqfQdhrYcd+shCYsYcEpn6M0QVkaxsF1NdxHjr4dltf32JciLQ0VZ2GaJb9d9K7HYjuVONOsrlw1vYgH8RHnEnoABVTwPia2UOJxUPeuEm2OYG2Y9J5RyFNuoq5VRcnZGtXiAXKLyi3cIzMgObKOpaAP5pNV+P7W2EECSddwR8jqKw3EONXbrEjwyep/eodjBSZMk0p1ZywhypQjvk0WL7T3Lp0kL0G/xptviF46L4V6L08ydTQ8Dw6eVaLA8M8qtCnbLBOV8FZbsXW3JqywnCzzqwa5Zte3cUeU6/Aa1Fu9qMOvsqz/BR89arPiaNPtSX3+xaHD1anZiyfY4dVhawY6Vkr/bVvwoizzMn9hVfe7a3zs4HuArO/wDI0/8AWLfzqPX+Oq/7NL9z0e3h6MlmvLP/AMsxBj7x9doIj4ikHai+Drdfz8e09ao/8i+6D9UN/wDKl3zR6wLVKLdeY4XtlcALd/IBghipJ0mcs5o86v8ABf2h2ngd2fOCf2pkOPg1eaa9/sZqnA1E7Rs/nU2At04Kaq8L2mw7CTmX1Ux8qtcNi7Vz2Lit5A6/Denw4qjN2jJX9/QzzoVIdqLCLcYc6c1wMIZQR50/u6aUp4ogXOB2G1QZD5aD4VWY/hd1AdJHUfqOVaHLT1uGg1dNBi7O5neF2cygxBoXHeMnDMik+2YJ8teu1XmK4erS1s92/UbH1FeXf2j2sUwHfLDKcq5ASrrO4PL0OtZKdDlPBslWVRGoaxh7gkqBPNSVP/8AJqlxfYvB3Dm8c+bE/Ws1wN8WoAho8/8AmtrgS8eIVtSTMjwVFvsVhlMgE+tWOH4Fat+ytWmlLFWKEZLAG1KRRWWmslEAKmZKLlppWoQGRTTT3FCaiAQtQi1OK03J/NKICz7O2sRYz9+LJJJhreeSs6AluQHkKru3XaC5CYfDSbr75T4lnYSPxEfAa9KL2p7RG0gFtMzMDlB3LbTHNR8yQOtUeAwn2ZDdYM2Mu7Id5bUz16sw229efQhb6n+xrqSvhCYANhlGHENfuAF2j+7XbMeoHIczV1hMKAO7QzhbMm6SZNxx4smb8QB1bz061Fw2BM9zm/8Ak3PFdu/9tdpHToq+p5axOM49LFvu7ZHcW9FG/euCZZp3VSOftNPJTL5NJXZSMW3ZETjnEQ9wXnBBj7mydAi/nuLyJ0OX0noc/duF2LHUmdfXoOVC7xrjF3ksxnXep+DwpYiNukUnMndj8RVkJhsPOwq9wfDwozMQoG5OgqLexduz4QQX21nKvrH0FZ/F8VuXT4iT0HLzgUmpxMYYjl+w+nw0p5eEavEdobNrS2Mx6nRf3NUmP7S3nB8cDoDlHwFDwvZ/Esub7PdKETJVuntbSRTeFcIfEZhaRfBqcw1PLQHeufVrSn23j2N1KlTgvpWfHvI9m5cuEKoZmY6ACSfTrTcRh7qtDNlPTfTrpNbbBdn71vK1pUNzLBJyaSCCVnX5VIxvZrEXge9KCABEqAABuJIgnnPWs3M0yxHAzmeMvcwFwKNTdLH3g+7rTb+HZHRe6JZgCFbxMQ2q+EGQSNYPKDtWjwXZVmuIFZGTMA6yYy76s2gJEkEEjSavcPZztcYoC7Ow70FSy+InIF9rTSMsac+jddnZZLOotzG2uzuLulsloKF3MgJy2aYY67jSmWOG3UBFy0RJ1DFNhpMEzvpI8vKrni2UM95bjhQ4kFjByycoMbDTw9GFZ7F8Qe8pYuBlHPQx6jy5GpFzb6fOpV1MZNVwrs/au2WgQ6nVcqldgcwI1PuqHb4YlxiquAIhFJXygu05QSSdJERGugoXAcZ4Cj3Cjw2R1gZ1MMUJ010GvnyAmrjBYZEUMZQEwS0KjaZgoO51EkaTlAqq1pvVsK1LdGbFkg6HxKT4VbMxiJKidRB3FWeHuuu5dY/MCB1kGIiPOhXe6fFZVtu1wklRbCaSQRAI6A9fOjriCssZJDAKj5UAbf2FiV2klSNaLnFw7Ny6ck9y74d2pu29O9DeRIYfPb5VrOF9rrNzw3PA3Xdf3FeScUxItMrhFi9mPd6ZBAUEpG2s7aeVTMBiHukwzSPwyCRH+fU9JHwptN1aeabt0eV6fhgqUKdSN5L91hntysGiNQRII1HxpCteW8F4/dsto2nNSZHoY+tehcG43bxC+HR+an6jqK6HD8dGctE1aXs/J/wcviOBnSWuOY+P5J1NxFpbgyuJFEIpCK3mIy/EOHd0dRKnY/ofOo6itZfsh0KNqD/JrI4m0bblCdvmORqyYB4ilgUJHo6vViDStMIojPTJqEGka0xjT5odQA2hNRjQ8tEAIrSxT4pCB51CGc4Zg7izj78szH7pB0PsELz5BR76tMJcLNN0TiHkIPwooiTp+EaZm5mAOVSbClnF0iLmvc4djGWdCzdDB1b8IMDUwQcVxJtk2LS58XdjPcSCqD8o/KByB2kk6mk7jdhOI3+7H2Sy/eFyWxF4Rn/rJOxMfAAAViOLXw9zKBCJCqBtoBp7tPhWzXh1rCYW/lcXbpUC6wmASZFsHkefXUE7isFaXxQd519edIqu8rD6StG/iTMFYLHSpOJ4lkBt2va5t+i/vTXWFVAYLnfXQddNfKq/D21ZwNc0RyiSdNzWPiKzX0L9zbQpLtMjXLTsYyvIknTpufdXqHZnEraw1tEshLhUd40asSzb8zoBrsJFVXB8DbtXIFrxMmrsM7lyTqpDFYjnE1c2ntoc1y4E0IAZvxKoMHpE8up51ya1bFo7m+f19oPdOLbNmbwgf0QQSNIAkj38jqeeawFnJiTESGLFQIDnU6AE6gTAGkDypcZ2ncI19E+6nLIMy0cwTPNoMbGPKszw+7exVy5dPt3TFsAfiVlJPlpI35mhClOSbljr1KatOEbJsY3ilzlEkgGdBl8OQkZdgcw3BOlMvd1btyiopKJqCZLHNJkjeGXkdRUfhvZ3FtBvvasqHDFWYM28dCBImASRrqKXtXwu5bEkL3RyqLi+e5K6AHc8h0NBxulHD7gxnFsB/wBZVC1h1lCoZGOjkkDTRogkb9KmLxFrinIBatiSMuVS8SN5LDeAepFZvtHh071TFwZk1WMyBlAjKwPs6kxJjTlRuI4jvCrWRkAChoZiFygeKY0BI3B89K1aYr6kLvfcLib9vEPkNvJcEKIBHMyGDc9Rz5HqaqL9rLC+FlUk6xDHeDpqJ61YYXi4Qk3NVG5gl4AIC550GvyqmuXL+PusuGtFmnM7EqAJO5mAPd8KNKDcs7Fak0o9QWKvqyyxKSZhdgRMEH/mrLhmPzKlrEKQrgOpIyEgyq3FzAeAge/er/gnY5LBGIx91btwai3M2l6Fif7w+UR61GfG2cXirtyAQcqK5G4B2BG3M1aVSCTjHNtxcVJu7AcH+5xCgBu6ZlzuDCnKT7NzTYtuOg2iRJ7U4vO0Wwipbn2YJ1IOQONGnrrqSdzTMdwW5aGaySFHtKWLoT0EglSdNzrB25VFjGghkuIc4zGCRKxJBHJgYOutWpT1L6Xde4ZW3JPDj9oRrTxJIyRK5Lkwx3gNAjzmmWuE41RAs3iMwMqrEEjTddtJ1kb1T275W4W05EONOk68zrW67L8eLkqImYCtOU6RAO65thyEfC1W/ci9OrKMXYg3sPibasFDrA9kyZ5yCVBY8tRPnT+EY26jK48JJJ3GYegmY8q1fFOKYM2jmuIjASORMactG6SOdYFbiu2YZRLGSvizA6exOcH001FUq0Yzjnfz2GUKzzjB7NwHi4xCToHHtD9RVlXk/Z7Hth7ikFyNN0Imdx8K9UtXlZQ6mVIkH1rfwNeU06dTtL3Xj+f7OXxvDqnLVDsv26Dyay39oWIFmyMTlJykK0dGIAPuP1rUmqTtlhlu4HEI2xtP8hIPxArdsYjFcG49bvnKPC2XNlkHw8jpty086vLZ868l7HYwjEsdBI03OkCNvSvTcHeL+yCfdVefBO0nkvypNXRYhq4igTG8CjrTVKMtmLcWtxhNJFPamVYAhFNIok0wrUIMC0uSkNNioArsRxW6znD2FF26f72+R4VAOyxoqjWI+Zk1K4Rh7Fi2TbdkExcxB1zHmtoGefz6nYuEs2rVsKhZLJOxH3uKY+uuU+6R0XcXG8etgB8Qga4B91atmVtA6BjA3j8XqF0klfRDBe0Lt9lPhVELLkX8cZiS1zX2m6bjWdTA81whl/fWyGBv/ZMTfutm7zu2QcwELbLyXxaDyrHYRYuEef8A6rLPEmaodlEl8TF5mzQVEKPDJPP2vf7460bhapZa3dNpyxzmfaAhI0zaGJkjSOtQZUKZeSzLmCOII31BXQid56iBUnh9pAQ7sDlYHI0+IbkTyOlcucrO7OrTimrGqucUsWZukBS5ZltqMoGaZJjYctN6z+N4x9ouqtu2GklVXTT2tRGnOdOlQ+0t5LlyLRfIPzRmJiNcpIj3/Cr+zwmzhUsYlZdWUMXYSM8wyEDRYO3puaUqSSdRq76eYZSd0l3h7vBmWwS5yd2bbwviGaQYGacpGUaajX3VZYXDsLathyudiA7+1cAMlgqzCTEmBzHuh8T4zZtpLIbiusgsOYdhsD4B0HIEVn8XYfuLb2rhDNnYANA0y6FuegGh2PzpNOV42svHz+eAI4ya+93S3cq6swhmZpAXQscxkAmP+afgcbZa6mFgG1dV1ZPDkDQWERt7JHw6CszwjD3ny3L10FYDQo8TH8p5mCCCBuVjbezUl8dZuqkhSWz6yfu2GU8hHSN+eopcIKMtD3JPMbrwMtexl3D3r1udAWTaTHL0kRr5mrzCYW7cQW7JzhcxcWy3iOh7wq5EGSFjTbTaq7tbaC4s3R7N1RcUxOhXK2+nIek1adirFuwty810fekBVAYmEkxHqT7qbKSjT1d7t8+5SN2yHhOzD3pbEMbNpmjIAO8cg7KdQuvqeWlPu8HGdRgrK2e7Ptic5JEHPdPiYdV8Q8htWkCl0a8EAKtAmJJEzAE7zHurr90PbVz4A6RmX8JGhE9R51lqV6sbeHh+V3juXFlXbtBMxxbrccLKqWzKPOIAJ/m9BxWJyIt1AhZl3dQe7liCUkRByEbfGo17CKl3K0kNsT+syD/zUXidsqoIVoJkQQAMshpkQdj7oplNqTT/AIsFpJGiwXG2IS21tSXAAiBrqwYgmPEJkT022qo43hrDx93znMrMrCN9vYIMcuWxoPC77XVvZlJChddsgH3ajy9sRH5dgBQMLjBbDPcY6A5ydRmg7EazPLyq/Llr1x3RRabWBDhyXbjo8paaGR2ObIywpNwiCyEk665Z8qseE4P7LdIZA0aMJkgaNI6iNfQ1TcMxt69iO9tyLaQqgHZevmZ1+HStXjVw4tZmIBOoYAKfCIyuDsIjT4HQGm15zVo2K04xyE7T8KQqbyoptnxtOomDuPwkj8SkGayad1nIs22jQgPDxI1O2kEnWZ0HuuOB9p0WLdw5rJVtgTGpO0+IElpqVxXgdpAt60SLNwfh8WQxOWJ1B156Hyqc2SVn8+e5aMNLyVWE4hdWAHjL7RJBjWP21Nel9hcUzWnVjJVtPQgbe8H415UuFDZjbksD4o/EBMnlHpW7/s1unO65WUZdmLSddDDbU2hJxqwfW3rgXxUFKlLoegGqLtrie7wGJfpaf5iI+dXbmvO/7ZOLhcMMMD4rntD+ka/WK7stjho8jwylczBuS7esVoOD2S7B3ZjA08TACNfwkVn7TaA/0/qpqy4PkQ6aHaf5vWSr4ofA9Jw2MOUsfl/OtSuGW8S2HLXxbDq0xbHiFsci0nXfUVlw14p9yyZ5X25ygAgnTnt1qz45jcRh8ML4ZGJGR8gIXM3hAgkkanrWRJ939j7W3/osOz/FvtFrvMpUgkHpoYkVYE1T9mcJ3GGt2zuBJ9Tqaswa7S2OcwpamMabNLNEgxjTZNOamTRAVvGeOthj44vYlxAWPDaB/Cu/lylufKBcN4cto9/iJN94NuwdSzRzB0n5KBUrhXDDhhnaMRiX1CzqpPNm1HqxHkJ5ymsDMyoQ2KYDO7jwWwdtOg1hAZbcnnSW0NSDIhZoxBPfXVKrbSTbS2dW232Eu3MQK89xuCNjEFCI10/StRjuKXLBNjDBr11jFy6fEc20AjSRr/So09C8W4f3yItwqL4VZIIO+gY+UiJpNSNmpD6Uk1pMNxPh8XxlbIGI15ANuSOfP4VKVGclZZ1QHK4UmY2B10BPwmp3FsITbllh7fhdSNRrvHvPxFE4BxLuALbhRafxBwJMzoXOpKL4tI3A3FcqvGSbXp89jrU5JwTRSG40BSAIOkwDrv61oOzvFXtlrBAZLoYFXZVSSAA0kGDA2ETpvoDA4+MOjRauJdJgyBtz0PT12qme+SCS2v4csjYypnrSqepSvsadKqRsbq7gA+Ga0DZtkZZBc94RCxCsNZMnQiDIqka3btKFdiqqZXLDzPM66a7xvA5yarcJ2lvgKjgXUVicrjNqZmSIfntNP4vx5cUZNtbQAEhQYEaaCdPSjOMseHzJRUJJ/P5J2PxSItpLSOYGY5pzCRnLgAbSS0xEM1XPYvF53YsNFt3HkbaFB138RrN8AV++tXcO0FSASxBGWDIKndSCQfXlW7wdi0j3mtoim7HhCQAF1IA10JAEc5pVTlwzvK7KVIy7PQynE+G3Ps6O7HN7SJplXMAWWd4Jjaszwvind3BoddCpiGJEFSIOhnTz1r0HtRiEy2cxBzSCs+g8QGq6jn1oOD7OWbIW4bS3b2UXIaSVAGYZQRpyAO8x7qwq6E1NN32A4YTjvkhXOM3RbFlLTDdgrQSMwBMFtQN/n6VE4HxAkPZuZl7zxIfy3BoPjpJ8vOhYriPeXLisWRhGSCAFaDJOmuhGm29aLs12UN213j3SS7AIEYFVXNBaSJnQiOUfAqClHKy7fklSejfYo7nFShIcMpSSRAkcjvr8+QqmxfFFBC5yMxmAQ0aRrM8o08q3/bHhWFvuMLcJS7kmzegSdSMjnZhI59eR3wPHeytrDjKHYMMss2gYEwYG2h19BTYwpQaTvfyFc2clhF72FxqNiHslvBdQjb2mXxaRpAGf+HSh7dXou/Z2VQyN4iq5NAPCYEBiQRyqNwBXs4hbqktkcGdSDpBGm5IYj31rP7TuCC93WNt6yArxp5ofLUx7xTIxpxqqXQrLmWs1uH7Oth2FtVIIEBRAM7AAZo2A+fPas12txAZFlYi5AEk8mJ+i0zAcavWz94iXVIjxQHERlKvEiI5zOvWaBiEuYnEJpAZwB0BY7/P4CjFRhPU34mjlza28CwsYa21mSIZTpEagiYPoQfjTr2IKoCgMcwG33BkbTFeq8N7N4fDWYChiYDM4DM/x2HkKwHajA28LeD22CI8fdxoG128vDMHadPLNy23nzLw4hSwigtG2xJAI9xjXzr0/+zfhht2mutMtAEmYG/7VhuDcNuX74UDdhPTXbT3GvVsfjrOCsDOYCiAB7TnoB61o4OKlV1d0fv3L+fQRx89NPQt5fYPxbiSWLbXXOg2HU9K+dOPcebGYm7dYkjZRyAE7fzaKve2fay7iHKMYBGiD2VWdvMnSTWLwXtkev1rsatSOLp0sPZg21mdoPwP7UXDeHauww8DDXQn6/wDNPyUqoy0UXvDMTfLgrcCoImQGnXxeY0q340LhuWbCvNu6wuSNiLZnUdQazXBgzHLmEnbSJ+Zq54OHOJYsSO6GUL5tGb6Cl04J1VjYZKbVNm3t3KmW3qusNzqYr102YyQdZoTeVKGNEDk0CASPjXT5fWnMNYpsVAEC3jkIbIe7U63MSYzOdAWWeQ/MZAGwNVeJ4u9yMPhELKZm6JDt1aTqNTq51oPHUbEW2cuEs2zCq0+IDQsG/Ft4VbeNxUvgqqv3eA8RIBu3WHsA/mU7t0Uac/VOBpacI4f9lXurBW7iGALZpy21OnSQo5A6sRyG0hbdssyLKMpDX8Q0RmXxZQRoWGk8lBjc1Es4hCjKpNq2CTdxU+O4RoShO5/q1A5TyiDFviow+FhcMuju4y6bksZEzqcu53Mcpa+4b22LxMNbxts3bRU3klXA9m6vKfUbH+Dz7jXBe6cyjFTMDYgjWD6dPfXoWGVLADWk7q2mgeMzX2PJVGpGkzEmBGm9jeSxikyXVymBrzHSfMVlrUNaxutjVQ4jlyzs9zx/B93oLsxP4RMegJEn/UP3Ze4cV8h0MT5TGxrSdoux17DkuB3lv866iP6hy+n0qgsYzLdzOTGob8R1ldGfTNXLlGcXZ4Z2qcsaoO6+ehpOC8cs92EuFLLLoJhVYDSQTz0q1u28JdWXFhx+aV+tYEOCxicgOhaJ1+Rp+JwyqXDrDDTlv6Vz58FFy1RbTH81Ggw1/C/bGTDJ+HwMpzIGAYmR+IkQNCQPOp+O4wyPD2WVANQ4IzR4QVDQd42k1jMLdKRlJEbEaQeum1XfD+02IV1zXDdWSxW5Lqxggyu2pPKDrvWyNKGE2/Pf1M9Rtu6yWzWrdzCi82doGgJlYBifzCQOuk1XXe02ZfYMqgtswzE5RttIGx5U3iHFFVGVbVy2rsSFLKcrbuvKFnYeflUUX7NnC50uKz3V8QmGUhmlWtz0ywdjrHOgqGJLu6d+Rep4bGXuFXspvkSCFJMgkA6Cep/42rbf2e8QLWSk6228tQTmEfMVjsfjHw2FS0zAFlDMihWgNJWHDEEFSNNIj0qvxuLuYHEgo7Fk0dVJWSCQVB5rEEEjnsa0QptSsJqfXE9V7f2LRwwvkD7tl1BgwzBY8uXvUV57j+OWLy/Z8UZVpyXAJa0Rtm/Muu+/uMiH2q7Y38ZaNjuhbUspJJ8TBdVBAEAzEkaGNhtWcweDI9rcb/pVqlOLepvPT7kowajpZd2rK2XZVKsAdCD4WkA5gedbzs/xNcVZexe8cghmO7AwAT5gwM2+oJnevPLYWRqB9BVhgeIPbdSmmXlr4wdCCOhFZZuW6NzjGcdILiOGexfNq4NV0E7MDsduf82ogvKGBWM66g8gQd4O+taTtCq3rMlhnRc9pywl0BGaySd2G2v71VM9lLURLMNhlG4021nWlOonZpO5eEm46XuaDEdqb9y1mREUQupLHxHfKOQ20Y++sriRiMVeAPiJ2gaTAkR5fr51P4fwi+LY75+4snXx+23TJbGrctTAqScellSmHUrI8VxoN1p+SCtEKU7u2DLOVOm/HyL3D4yzw63lWLmII25LPNiOf8FYDtTx+45Z3bPcgx0UHoOQ/aofGONhSUTxOTrrME8z1PlWfa5mDAsSRMnqxGvw0HurpUKCpwt8fU5Veu5yb7xTmLKTuZ/Q0K2CL3vP0mir/hnX/wBqaDe0u89x8xWpGVk6wG+8Hvj3A0K65jQwaLgl+8YQdQOfkR1ob2GiVIiNjNUmWiTODqzHRhmGojTbXSr3gd5mZrjHV2LVR4e1kXPyA082Ow/nQ1c8FUgKKtw6y2Sq8JGwwtz37RVjbaqnB1ZW057ithmJKmnZ/OhA86VmqEH95XFqHNdmqEMf2hxoxV5MPbzIq6HpK7nX8K6x7/KtBhsCoK4ZGDIoDXjARoI0Q66M2hMEaA9dYvZcJYw9zFO0iCFzL03EjqwA91WAwzCyiQhv4gy5U5SC4l20n2V0HupDGrxK/jTJdsm67lbaMUs24zB8rBQdYJkggEHQDnUnCYgGwLhwyi3p9nso5LXHkgMVZYMkCJbSCehqH2tdA1vB2VBywMgcmWOiiANgDJ9fKrG1wdQ9i1b7201sd4xWCAIK+zqhLEnWOtR4RFuRuKcTFiMpZsU8/wB4pTJMSFkQVkwMuhjVtKAj4jDnvb7M125/hLBB2jbQxG4hVnerC/nFnFuuVhJAuXEYTlADQpVlIBkKNNTVH2fKraa4rXe+JW3lOYWxmbwyXDIFAJYwRQewe81HDe2CKwtscrRJU6j+edD43g+GYn2vu7h1zW4IP+Ybfr51luNcMZV7u0ma7GZ7g0DTMMwb8TRIgnQHQaVT8OxFxAqm4l8tsqsMy6T4i0frSKkZNYz5mijNQle7XkaPE9lHRCyXVvLIAFsMWIJ5plJVRpJ158yKosVwh1M3TlcsoyEMDE6Fc4CnbrpOsVPwvExm0ZkZTBBlSGHKdifKr7C8fvrMstwGBDgEQPKsEqcU8qxvjVlbDuYO8oRjD5uuo35jQxv50HvydNRGusCPTXSvQL+Jwl6O/wAFbMCJtlrZ6/hNQ73C+GtoExNseTI3/kCaHLXigqs+9MyV7F3bgVHctr4Rv5RPSkZF1BEkHWAeXr761B4Lw8mBfxCn+q0pHxWKk3eEYTuVtrizKktmFlixmNNWiBHlVXSe6t6ludHr6MxN1bYE28wfPtGkaQZ+PKuv4nNCuqyoiQI25mOewnoK0B4Dhg2Y4i889LMbctX0p9zhWE1k4k+YFpfrNGzLa4mYUyecDy/k1IGGYqzhtBykidtpH61oLOHwq7WLrj+u8B/4IKLbxdkE5cHagCPG125B5aEx7oqOD8UDmpdxnbtvQbSRIgzv1A5+VTsBwPG3RCWLkR/eMMi+4vA+dam12iFoRatoh/otpbHxiflQLnaEupNxnzToJJ0+lWjSh3u5X9XNbR+eQDCdkEQf/KxKj+izLt72IAB+NSmx9jD+HCWghH+M/juf6SdF91Z7ifaK2ggsB82jyA2rN4vtE5EW1joW1Pwp8af/ACrGepxEn25fsv6/k1eP4idXdyfzMx+pNZTiPHGYQkhTt1P7fWqp7jufES0akmf4KYpzt0A+lPhSS3Mk6rYTDWiAW5mY68wT+nxpuAB1Hp0o6GS8jkI8hGgoPDxvoOXOm3FD1nImuxX9qFi5zgz0+tGX2OWh+jV3EF1GvXlUW5GTcBa++XXcfQj96DhHdmy6c/XSrPCp47TBhqSNR1Wf0NDwuHId+UOwHuaP2qlR2ReCuxfF4bfIHOR56gfz0q/4alVVl+8vO4ELoB/pEfpWgwNvnT6MbRFVHdlxg10qwtHyqHhRp5VNQU8WPBpYpQK6agBppKUxSA1CAr1pi2HwkeBF719DqtswoPLVtT76MmMObEYo2wRZD27cg+0pAYmY3bKunJa6upCGsouySM73MVeXPlLxKkQTJZoiBudupq2w3EYw73VX7y+RkhvzeG2BMaKkH1J511dRaIiN2nxASzawtsXCBExLTlEgHeSdW/0zUtreTCWsOrsHxEK2moDibhMDkgI9wpa6p3IneJicDaN3u7bKiC348mZcxYZLYbKwBgBjr0FYzCWM127ZtCyyvmi48lgF0Bld5PXrSV1VtgNxMRw1Ia2MyWlkXCHzqWAU7GCd9dJmKqsJdvI2S2wCfhNyRI5AZtNQNvOurqW0nhjL2yienG3El7RCCRm1iVPi93u3FPw3aO0xgyn+aAD6a11dSnQgxnPmiUOM2soYvCnYmQOm5EUn/WLB/wAVP9y/vXV1L/Tx3uX/AFD8DjxOyf8AET/ev70G5xfD/wDdt/7hXV1CPDpvcMuIaWxGv8esf9z/AGyfpUG72ptDRQ7e6PrSV1NXDxQp8RIg3+0zmcqAeZJNV9/iV1tWcxyA0+lJXVeNOK2Qt1JPdkazamWMRUgWz08R2HSurqswIdeWPAJnn5zyrmSCoBG+p6kT8h+9JXUQBbKeJten0ND4fZknfb9a6uqIhY2OHk2naDAzydTsfKrTi/B8i2yQdSfwNzANdXVZbgexbjCqLGGcBT4rewhtVZarbABw+KuAgMl1svXUx9D8q6upVbuXUZT7/IPwXDQi+Y+taLDWa6urZEzssLaUcGBtXV1WKhM1Lmrq6oQQgU2urqhD/9k=',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'แกงฮังเล เป็นอาหารพื้นเมืองภาคเหนือของไทยที่มีต้นกำเนิดจากวัฒนธรรมล้านนา เป็นแกงที่มีรสชาติกลมกล่อม เปรี้ยว หวาน เค็ม และเผ็ดเล็กน้อย มีส่วนประกอบสำคัญคือเนื้อหมูสามชั้น หรือหมูส่วนอื่นที่มีมันแทรก ต้มกับเครื่องแกงที่มีกลิ่นหอมเฉพาะตัว รวมถึงเครื่องเทศที่ช่วยเพิ่มรสชาติ เช่น ขิง หอมแดง และกระเทียมดอง',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),


            SizedBox(height: 20), // Space between buttons and the next content
ElevatedButton(onPressed:_launchYouTube, child: Text(' YouTube'),),
            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}