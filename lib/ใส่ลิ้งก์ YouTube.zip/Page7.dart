import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';


class Page7 extends StatefulWidget {
  Page7({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page7State createState() => _Page7State();
}

class _Page7State extends State<Page7> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes
         void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/t30uMqG6VWM?si=kOJ8GxcYZz1nxK7y'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIWFhUXFRgYFxgYGBoaHRkYFxgXFxgXGxkYHSggGBolGxUXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICUvLS0tLS0tLS0vLS4tLS0tLy0tLS0tLS01LS8tLS0tLS8tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAQIDBQYAB//EAEIQAAECAwYCBgkCBAQHAQAAAAECEQADIQQFEjFBUWFxBhMigZGhMkJSYrHB0eHwFCNygqLxB1OS0hUzQ2OywuLD/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QALREAAgICAgEDAgYCAwEAAAAAAAECEQMhEjEEIkFRE3EyYYGRobEU8ELB8QX/2gAMAwEAAhEDEQA/AD5VIJxDUiGdWId1Ijis7hUlO8SBoYJMOTK4QxEstbQ4TOUMEnjDhKGsMCRc12pD0TGiNMoQ/AmGA7FD+t5w0IEO6qAQsuYId1sIJY4Q4S94AHYvx4TFCGWIXqRCA7HDxM5QnVAbQoQIYHdZDSuHhEPSOUAA+I8YcCdjBBEOSkwADOdoXAowQEF6kdwh4Sd4BWCfplmHJsi4LUndXnDAtO/nAFsjNkVwML+lVumJgscIYZ3CAWxBY1e0PCFFkO8OTNPAQ1U1tYA2cuzK38YVNmGphuPjDStUKx7JTIGxhqJYGYENxq4vw+8IrF7PfABMjcAc4c+pIgUA8fIQ1QVsBxJh2KgvrRsY6Ay+6fEx0AUZ9BO0OrtDA28SgjeMzQQE7Q4LMIZg3hwP40MBUzIcJitIRKuEKCHihDwtUOC1RwI4woUPx4AJUrVtHGeXyHhEeIUGu8SADfyhiHdcfZjkzTtDktzhym/BCATrjtCi0HaHoII18IVRTxPKABBN4Ryp52EJgB3EcQmADhPOrRylnc+ELTUViRKxw7oAORMhVTvx4cQjNoRKhoBAAw2pI3hUz9h5QpI28Kw2zliFCiQXHvN8vjDE2Si1cD+cInUhWALCCXd8hhLtV61ia1WHBVAOGrsC4bc7QZdUpQxJUnsljXjn5RSW6IctWivtSFBCFICWI7Tk0VsGTXXwia60dYFJWlNK4kkvXSo5xY/8PAlqlhXpPherFnA45Ex122Iy0kEpJJqR8PjDrZDloDm3dhSpXpkDsgeWcVhnEZobmHHiHEawJ8ohn2WWojEKmgqxOumcNxQKfyZdVopRiNx9YRVqP4Iv510S1LT2KAKJILElwwJFTrntGew+kQApI1AyHvD5inKJcaNFNMYbSd4jE9W573ieWdQBHYVO9PKJKshxk1bvYwxSidST3QaJajqPOOTKVllxpAFgyUnYx0SEK9uEgAookQYFAPtKh4c+sfKMzQJCh+CFpoIHS+qj4CJP5j4CKJCGAjkyw9YhCfeV5Q/BxV4iGBOUAbxKJY4+ECYOKvGHYPeV3mAQZhG5hxw7wCJfE+MKJKqsfOACwCEt6XxhRLGhMBIlrzc+JhDi3Oe5gANwp1UPEw0JRunxMDpQTrWJEylQASJEvUjxh2JAiBUv3m7xHYdlQwJsSCcz4RN2OPnAoCtFeYhwBbMeP3hASzChqP3xEFI1LREUDgfznCKkjh3QwJypJokuNfp8B3mL2y2KUSXDl2qTmB94oLIpIJcOAoFhsoBPxT8I0KZiU8wXPBwPOgg5JGUrLRKW+8KS0VqbWXpTYPBktyK584ccil0Q412eYdJps1NqmBS+1icMSWChiCQSAaJIGUH3JfapBxqUSg1UkscRZgz5HL4RoekHReXaCZiSpE4ADEC4IGQKXrR8m74zk/onOAwlcsjQgqBf/TTxjxc2HLiyc473dnPwlei/vjpaBLQbORiUHUSHwDjo7/DjFTYekU5KsRmFdRiSpmLvkW7P8rDKOldEJqRg65AYPiCSc2OXM76R1j6J2gqZcxCQCa+m+VQKFs6E6RopeTKdzv8AT/0JKfsbmRb0ql9YC6Wd9t3hJyAUkAAFQOQD5Z+Yitu65TImY0qK8XZUCW7JI7TChIbhQ+NvMSQQ1dOXGPWhKTWzWN1syktBKCoCgzGj/wBvysDTrYaBKAO+NVaEoTLUMIADluOQPB4yYQrQBgSBR8iRDao2hK2RqnTeAhChZ9aH9Wr8SIf1KtcXkPnE2ag36f3vIx0HCzj/ADD4iOgsCgEov6Yhwle/CFCeEOQhP5/eMyx4lJ9r88YXqNAon85wiZadh4w8BtB+d8UiRvVD24kElPtn8745AByAJ7/rD8LeqmGAnVg+sYchAdn+MLgGbAQ6UHOg5j6CABRKTqYlQmXVlHjWG9YRQh+X94cF1yaARJLkyy9VQ5MlDGj1745E5s35/aGdcliE4lK1ADtzJLDvgAmRKQA7RL2GDpLaUzgMqWRUoTyGI+NB8YOkWELlS1KWoJClupSsNCUt6LPUFoEJuiL9v2FcIclCP8ssd4srR0flMGcE5Y1KUOVTAqejhPqpTm/aUORBSrI92UVxZPNEKZCS7IyDnlvxiLHL9k+H2ieVd6pc8YOscF6qJSpOr437OjiFvGwzElS5YQqXUs+FSGLKS+SmPKnjCofIhC0DJBhs2en2T4QHLtnawlkq9lYbw0VzDxBarwNQGHGEUlYSu0YVhSKKTmOB38PKJ7NOWo4kyTNc4VFKgFIfdLv3trtGesk4lR2IoTqQ2W+sWNhtJCwyihbMFitPZUPWT8IznxumxNNO0bJEjq+0HalDy3zNYKkrJqfx4ohfGENaUED/ADEdpI4kDtJizs1oRMrKmCYl80qBbgWLxok1tdGD32GLnJSU1AxKYcTtzp5Q5bZHMjaOA0eGTJSiM66ERb5UTocpFeYaBLKDUZEEjwg1Dsxz0iIKJDtrWJlG2mND5T65xITESltUkBIGZLAd8Vk6+gaSE9adVZITxKte7xi46QmQ9JrXgYEMlsSjuQKDkMyYr5MrspKVYgQ4I1erxmuli508dUhfamFlzKsmWmq8I8EgcSdI61Tky0glRoAlLFiWDABoiUl37G+ODNQiQxd4mTLar+cZXozfhXLmGcsDq1sCdUmoHE6RcWe8ZaiRUHSucToumGlaPaEJA5VwPjHQCM0Fk60/OMSY+I8IYk+9CgUzJiUaEqV+8IkQePlDJaS2UOSjmPzlDEPCq6xIpQ/A0MQM84elL5+MMQ/FqBlC9aSfvDUJ2+sObl4QAPVMc1EcqZhrTyMMA0+X3iSRIxKA4gV5t8Qe4cYYm6JJUxRIOgqBSvNwzcI0RumWsapq7J46N4nvhLNZUIKfafNsxzg0TAktSL0uzFyvocmzob0EniUgl/CHoSKBTKbUgZ78IgvC0qShSkgqUA4SNePdm3CMWm/rQ/8AzMWrskUqzhmbiPCM55lBmMpqPZ6ESDrSElSwkMkUGj/WMrZemCAlpqClQKRQUIUQHDnRw4cnVoqby6azjNPUBKZQoy0vizdRqCkbB9KxEvLxxVti5xo9BUkKDEU1Bhn6ZJSUEOCGL5nTPXSudIo+jHSdNqJlkNMCXpUKAYEjUVIp5xoUDSNseRZEpRKTT6MdefRqb2glpkvMA+kTyoARuCIqf+Az+rWtaAnAklAmrSFLIFEqwkjTMkHcHOPRw+sZ7pXaFoRhQmZMVMNQlBV2TTD2U0DnygcUtmynJs86uuwzys2mc6cIICCK1pUeqOGcFotPbfjBl4WhXVI9IOoJIIq5SVJCtvRI5gbxQz1kVSK1/PhHm+UmjsxPka6y3shCXXMCa5E5d7UHlB0mx2S0HrMCXOUyWrAe5coh+94xd3qExSpc2WFUcVOWRHwjQ2K8UNXEMHZCSNqD0c/GIw+RxScmhZcK9i+s8hYpLtc0NkF4ZvmoOfGCZYtQBPXyS1S8lYd65JmUiklXg6RhDHFkaHnSgg28bxKVBIxBsJJoxSuj70PKOvH5EZK7OeWJ3RZBVoP/AFJPchfzXEU2VaC+K1kAZiXJSP6lEwBIvOYCxTiJJZgBSlT5xYXhawOwQolgWSCHD7j8pFf5EOLldUT9J2kL/wAIlkBS8cw5jrFlVeWXlA98WgIQEJHcKADupBsi1JUlw4AzDGh24xQX9PEwUWEhIGJ6VJYVhZcseHpex44PlTRlLbOmYldWHYV1AG3OMted4KWoJxOpRYNpyAjSX9a5tmSJcmQs4gwWBixE5nEHHeYGuK5hJ/fndqcrIZs+iePGBVJW/Y6qa0iysF2y5aBQsPRB9JSjmojQnLgIgvm8USUnEoY2dhpweB77vsSAVKUMbU1CeA3MA3HdPXtaLQks+JIUdNyPmYUW5/YcoqOl2bWwXx+2jsqPZFQOELFEu/QCyEFSRkRQGOivqr5J+iWCVHL5RK34xiETuDdx+sPRPO/9J+Zi6M7Jwn8aFCTx8IaidxHhDuvO48BDEPSfxjChIfLyiNM07p8BHCcr2h4CGBO4/AIcDVq5bfSB+sV7Q/O6HdYo+sO77CACaYopSS4oknI6B4Ku1KsSkpKgAKkcGAfwMV8wqYpKqEEeIaDbAoFJWQWeWVAZipSumocw0Zz7CrKs4MblxMwtvrF5RnI2gc2UGWQkgYqhQDhxkeOTR36huypJxB8teUKuPZDd9BcyawcAkbAfLWKq3XNJWcSkYK1UlRTUuX2zrlnEv6sp9IgPo5fx+kTowzGo40ANN35xDkp6/glwXuZa++iOJSOpmBgXUlVSUtmlJoohTH5ZQBK6IWpVFqGFiy1FeQ9F0nLIFtDvHo0qSGFA4yerd8MdSswWGZGRPI1jKXiwu/klwi9UVHR/o/LsyjMDqWXTiIZkliwApmnONAmeHZ9vPKAZ9rUhQHVlSHALZh9W1SPGCZaQC+h33zjXG+Pph7dlcEkEARDbCoIJQ2Jjhd2fi2f2iVKgRQxxUwrHSq9iTz2+pC0SlmcHV/zC+6VBQy1o/fGSmoUSVBwxcbFwHEaXpleyElKatMmBA1NXJJPj/TGdmzyjElNeJ0qfGPN8yqX2O7x7/kHmWtSFYkVIPZ3I2I5Rb2ATV/uAgPpoG+cA3VMShLqbEokk99P4YJu+WOsmTUE9qjDKjVbf6x5c1HjTOttlkpc1OYQ7aA/WCLDfLjBMQlaiMOFQqX0HDhAdnWUElbrGbkmnACCbvVKVNxpOYDc+HlD8WTttMiaVbRf/AK0JIGFLsKdpx35eYgK1X4gqwAkkVZstHY18YmWQXNSd4zVnWn9VNcgKKgGf2QEivd5w/J8jJK4rr8v+ycOKL2zW/qilBwgkMC2+z7CPN+m15mZLRJA7U2aaJdyEEOeVUtGyn3gQldCsKThAT6WTffgBFFKsYCkqbEQnCn4k8OJ4R0+G4zabfRMotWkgOwybYiUAJoTR0ymclqsVk+bQRJvNE50CYEWnCwCwAN6EZaVrAHSK/U2dJGJ1HM7+6nYRT9FrrmTXnzf2wfWbtNoEvkI7HDnbXXsVzUdPsNu3ozNM5U22MAg9lDuDrifbjBF63ylQzwyRqP8AqNoPdiGReCpa1TQtc2QEKDrIBUU1ISzOni0Fy7nk2tKLTJXMQA37aghqapCmDatkYtuvTJUTGu0VgVa1dpKcKTkHZhpTSEgifdl44jhtyCNOyB5YaR0K8fyhXk+H/Bown+AcwBD0tujyhvVS9Jaf6Y4LSBRH/j9Y1MiUzE+0keEIJ49unBP2jkWgjIN3j5Q9U48PGGI5VoGiiO77Qom+95f/ADDklWh8/tClStknv+0MDus2J8FCHia2p8FQ0E7DxP0hcR4eMADhaBxPd9YbKtxlrJBISancZOrlQP8A3des4/GIrQHDvUcYUnSsTVmil3gACSBSpY8HduXjBNivUzQyAojRRlqwvtiIZ+EZCz2vCMBDpPquzfwn1Qdi47zFjYbckLwJnCSGpjJTiPslqDPM5RkpS5ena/kmo1vv+DSqkJCQVqGKpLeYA27obYbUAsoCVOBoMq+A74SzrlraWtCyWzU2HjhWkl/GLC0HCGSz0oNnD+UVV+qL0v3+xD+GTTJhCXAc6DJ4bNm4UleEv7IJqaABsu+KW8rSvGlEs9Yp6ijBNQo9xKfGLeVOCmFKVOz8NxxhrLyk0v0+4OFJMlE8KFM4hmWkYsLZUdxzMVthteOepzUJUcI0TiDPxy8DEa71kScRmTElZJZCXWpjX0RrzjNZZZFr9/sNwUey/s6gQGipvu+WeVKIK/XVoga19qv4YDMy1TwyU/ppTZms1Q5D0PysRWmxIloEtKW7WZqVNVye/L5vG7nwhZCjcjH3ldCZ81Jcky0r6pOQ6wgHGpqeqABxOcUgWcTnPj/4nhE98dKUypyUIIOGaOsVoAF9oDcgA14Qt82dlmnYUokcA+XdHHnhKUE/f3OvHJRdACZgPrENBd1mYCSGKTpl37RDZV4T2gTxFfKCU2lQIwulzs/g8eXk+DsTDLdeK5bDAXVQGjB6OYsrmu5KEghwU5cDFUkJnOmYokioNA22QZ4tLNbFANhrq2R5RkmoaiJ20Xs7EJRXiTTcFu9oksNik9Sy0pJPaUrUk1JfnGZveZOUEh2QSXSDnsT3xY3etaZbqU4A4dw4xo8sYPSu0ZOEq7IZrJdKXatVO7E9keDxn+kfSFEhGFB7RFT8hwi3vi2CXImTVqxLCFK7wkgNwEY7o3cCp6habSP280pNMWxI9nhHb4OFNOXt/ZOTI1r3I+jnR1VoX+qtX/LFUJNMXFtourfaxOBbs2dNC1DNOiE7J3MSW619a79mQmn8ejDhGcvG2TJ8wSJIrkAMkJ3Mev8Ah0u/6OdV2+v7IrXOmWqaJEoaMW9GWjJuXxjVr6JyFJHWFRUkVViPwyAHCC+j9yos0thVRqtRzJ1iDpFfSZKHerUH/sfkIh0tFq3tlUbsCOyLVhAyBAetdecdFCmwWyb+4EsFVGI15nnnHRH01+Q/qfc34s3vHvb7Qos3vf0j/fExlpGqfH6qhwCTqPL7wWKiMSU+2ruIESlAycn+aFwDU/ncmHJSO7kfmmCwoalI5/zCF6lOmEfzA/EQ/CdQfP5Jh2Hn/V8kw7EMEse0nx+0KEJ9pPmflEoScwD5/wC2FQDuR4wwIkoAOkcopCVFRAAGZCqDd8oda54lh1KIGQFSSdgHqYprVafXm0A9GW7txV7SuGQ84LGlY+eW8YmmkYJZwgs4UlQBChWlctKhjxivl2pUxOINrxyLeOXjCqtCqetXLLujzcuXhaXZrGFsu5EmxpCSmdMs6izhC14Emjvidq8Yu+rnpCMFvfrCcAUhBxMMRYipYB3jHKlGaQgBg4xH5RZXZYkSJqV4HYFIqaFbOoaA0YxeDzHL8aM8mCK6ZeBNsGJ58ntbSmUaal2PKJbHY7SxBtQS+eGUCfEkwqLeAACQC+TueEPVblJxECpACTsdSe6OmeXHDbZgoSehDdSSrBMmzpj1YqwpJPupZ9TFlYbukyW6uWlB0IHaPeaxHLtQLJUoKV7TMO6BjewUoGWkq0c0bkIf1scVdhwk9UW/6hnerZtGO6SdIwhRATVAJOwoSC/cKcDwjQT5hZgk1/DGO6S2WXhK1MyiAtzQpdLJzpTF3Ebxzf5LnLg+maLFSs81uu6FT0mdOJRJqScjMOyeD+t4cNLcHSCVM/YnJdIokPUpA7LKzCkjyHMRTdIb4x9hHZlj0Ry+A4RkZ84vQkHcfLaPT48jGTSPU7fckxPbs+KfK91PbTwWgZ8057CAZVqUpJSkV1BzDcNDFNct+TkJBmEuPRUHChxOEgg8mjSy7+61saZc7X9xPb2brZeGYBwL5Rw5vHhL8n+6OiGSSXyOsRSXBU3dU84OlSyKoU/MQGJtld1ypss/9uen/wDdLwXYZ8hIOFc8uagzbMfAARxS/wDn27TX+/oaf5GugmbZ1EAqYkmjfWJ7LhUGcrqzJqH0BOkDz7wsyUYl4qAh5k3CK6YUAA9zxXWrpcoyymQGSKAgYUgfFXfSNIeFCP4n+xLyyl0h96SUFYkntkkKmAZBKTibgHAz24xDb54m9pRKZCaUp1nAD2fjAFjQnCZi1EoPpE5zVO5G+B6ceUUt8XsudMEuWHUSyEjT88o9PHHitLfwRL8x95XgudMTKkp7RolIyQNzGt6O3KizIb0lmq1nMn6RD0buNNmQ5rNV6a//AFHCJ74vRElBUr+Ue1/8/GNGuKJVt2df18okoc5+qN/ePu/GM9cVzrta/wBRaHwO6UnNXvHhEVzXau2zDPnv1QLgH1z/ALY2s20BKQlGZAYfCnyjGUuKstLk6FVMSnsuA1GaOiFVnlP21srUAZE6QkYc8n5GvGAex3b+WOB94+X0gXH+P9BCH8z+ZjejENJHtef0hqW3J72+cCpSB+fSHhcMQSDxI/mMSpCdST3n6wICTv3fWEKQ3aIbiS3xaGAa8vXzUfrA1vvKXLZITimH0UA+aj6qfwQJalrwfsoSHzmEDsjcJIdR20igtNsRKBCCSo1UolyTuTvE8kXGHyG2u1YSZkxWKYRRskjZI9UeZjOXjeRNSYDt14akuTkIPuPo6qaRMtFE6I+u54RHffRd1pE3Rm2KCVFSSEqJKH9YMAW7wPGLiRNGIbHJ9/lCXnaZbolpYKQSoNwDEeHwhetSsBwMQoY8/wApbtFxLJCyHUk123iYX7LGYOIEUY5555ecZla5qnRJUa0JPqjVjD5t2TQlsZfwrHIvS7bNOCfZeIss6eoTMeAg9nDRhsfa74sbQuYSmWma5AOJTChGlKPnFNdklZlAdZMKdO0XO9dQ70g+ypMlISgAupg+j5wPJ7Pti47+xadH1K6xRWsqwlhFhZ8KZswU9Ikd9fnFHZlqQtWFFSe3XUajujQ2WYgIClYS+b1rpTeLgrXFtaM56d/IlrtRA7HjGN6VgzJDOlCSsOo5BPaUVE7nDlwEaC8rQpsTuHBUB8K+FIxn+I+OZIkypKSXWl2GZ6tTk7AUD/URfhuOTKnfTJyXGOjAXzbkE4JL4Aczms7toNhFtc3R/q0ibODrV6CNn9ZXyEF3JciJBC1tMneqluynjXP8y11E6cizArWQueQ/BEe1ly36YnPjx16pFLbLuEpGKacKlB0o1b2leyPOMosmesgDsgtz79BBtutUy1zCEk4X7a9z7I3Pwi4lWNMlASBXKmnDiYytY/ua08n2EsFmwgfuEgUACiwjQXLcE21nBKWpKH/dml6f9tA1U2e2uxW6uh1omo9ESkqriW9A7ulADqP8TCPVrqsiJMpMqWjClIYa8yTqSak6kxtjwcncjHJm4qomfuvoVYrOHEhMxesyaBMWe9WXIACCrbc1mmJKV2eUQdkhJ7lJYjuMXM9PhAU0x2NKjlTZ5B/iJcUyx9X1JUuRNUUy9SiZn1ZbMkOQdWO1ZOi9xizpK1sqcodo+yPZHzj0PpUgGxTCo4cK5RSWcglYT2feKVKAPGMROtKZUvEuiRkl8z7IOvFUYNKL0dMG5rYReN4JloK1ZVYe0duW5jI2CyzLfOxzC0oH/U3qp4CI5SJlvnMVNLGZyDD1UxubJIRJlgAMlI0EZN+7Ne9Id1iZaQlKWA7IHyEMV+0Co+mf6R9Y4rCWmKHa/wCmnbOvNvCKmZaipRLnPPJ/ERzu5M01FEyrQ5fOOiRK1bn/AFn/AGx0V9NEc2HJmJOniSIkCuCfB/lDijgfA/WEUDw8B8xFiFFoG57kqHyjhaxqVfnMxGonQ/D6wPa7QmWnFMJA8ydgwqYYUFm2hiSCwqSWZueKKa8Jn6li6pclLl3YzDuGqEjfjEM15nbndiWKiVm+xVueGkV95Xhi4AZCIlI0jD5DbHeUpMwS+2mh6taSQSwqlQyVlqPvFeV0rnEGzErJJ9MYASA5AIABpwAz2iku9MybNCpaCQkHCSKOaPxABMaGTKmySgzZoUrGWAfs0OQ+nfEOLWxqVg9w9H0o/dnkFQ8vpz14RH0g6SpSMKDwDfL6xb9QZ0rCVpNOySkJZiQE4kMUtk5BGVXpGJk9FrSuYBMHVoOImYpSTRJYsAaq8o0hUnbIm3FUkC3bOmTJ4UAVFIJU2SUsanYPGxskxNFEZivyPyMAzrVKsyBLkJZIIUompmEFy51fL4MIPtMnCQpIOBXalk6jmM9j3HWOfylfqiuh4tabJbPQlQcahgcjyyh1lvpWPCGfZQ01O5hqLQlqV93V4ZJs7HHQrd6ijeyOe8eXGSTbkdPaoPlSloWohSkoJKmS7B6mnE/GLOxWzEpkpJI1UPgIHslpC05VGcVtpTOmTAUKwpT6OF6lmOuTEjvjNeqew7Rr0TkpfNSzUjX7d8SSZgwYAKkMTsYzN0qWh8YIJbPg/wBYsbTbAhGJKgSTV/sYwm3ycUJxoMvGwqKQEqGdeXPSM9e07GUgaPiY5PQc6B++LWbeCcKTVlUJFSSASwf8EZC2SgtQmKWpASSSUkip9UDJRwtyfSPS8PEtSSpGE2/cktNsMkBZ9IEMTtr3N8Yzs6Yu1TChJOB/3F619Ubqyh04qnzDLQVYB6SiSWfQO/aNIupEhMpASnsgCnPnqTqeMeo2oq32TFOX2Fs0lEhAShNcgM2f4qJzMeh9EeieACdPAMw1CTUS/qrc9w40n+HFydev9WsftIJEoaKWKKmAeykuBxc+qI9SSmNsGDfOXZjnzf8AGJHLlROlMKmJEiOyjjGYYr7TZu1TIxZLWBGX6T9K5dnSsJUDMTQ6iWSHAO8whiE6BiWDOSaStjim3SKL/ES+5UpKZKlUSccxsypuxLG1FOTp2dY8ut8yZalgkEIaiQCwSMgNhDbRaFWyeVqcoxE1c4lPruAczqY0UmxYUBJ7ROSauTpT5bRxZMls7YQpUR2C1Is8vCpOjpwMpJB2On5yiwu6048U1VEpbCM34/SA7tky0TZko4VEAqUM0gn1E1YkDM5VaCbVXCkBgBUfCM5S9jSNENqnKmF6MaMXy7onsNjyLJ5VEPs0nd22dX1Ai3koGx+P/tDiqIbsamzHZP8AV9Y6CQR7KvA/WOihFYZ/LvENXaeKe5vnERshOoHh/uMVtqtHb6qUoY9SrCE8kuO0quXx0VIoOtV5YCAHUs5JDDvJaggQpY9ZOVjmeqMwngkfOOkSwiiBimH0lHN+fyge8rYmQrC3WziKJFWPEcOcZNuXRqqiQXpa8IxzNfRH2irlySrtLYHRB+J2ixu67JkxfWzS6tzUJ5bq46QdaUJA6pCStR0Zy/8AbwgjSZMraG2a8OqSAoAsKkCo2/iHGMzet/HrgQp8KgTyfId0S3vbwghOIrmOxAq7miaZnlrBN1dH0owzrUAVCqJXzVueGW75RuopK5GTk3qIbc8manrZ6ThTMUCnGohLBKQ4SMyS/NhB9mnJmJSiZMCQpCiE4Ul+0cTP6LOMtxFXe16k5/ypH55wsqxqKU4phGdUUopiU4s9OEY1e0ap1oivXo5MxdmaMCiwKklwo5AtRiaYng/ozeSUJNknpUqWDQq7JcUdJ9VQ0NaULh2BAmIOGq0KFApSsT8FDOtaiCbTZlLqFZ1HMekRwyNN4pypE8VIt7RcywMcoGcgZqQHWkf9yWHUn+IOnV4Es9oCzhRhJANX2zins16zpSwlQUNpiCQ3+khQP8Oexi6l9IjMIM1Eq0FvTUlpgG3WyimZ4xzZPFhPa1/Q1klHQ6XIUAVF8Otdos7HbUAZ10GdICXelmUGKJ0vhLnIUPCdLKvOJze0lj+/aE0oBLkHzSx8PGMH4Lu01/v6Dee1TQ+feEmcplqwAZFs+8RFNICRhlsDlMmYmI90M5B4AwELRJQSUIWXB7U1KBnxmY27odaLZ2XmdkH0UJcFY3KldoI3yGw1jaHi4077ZLySaofb7elh6ZSKEqYKUc2SBRCcqVO765S12xdomYEUGRIySM8KeP8AcvrFbbauevqpWWRIyAzwp+/MxobquxMpAAHMg1d8huOJz+HSoqCtiXq6HXfZEy04QGSPEk6vrr59/XPdq7wtHUyyUyUsZ0waIf0Un2lMQO81asM7rLVPFls4daiXI9FKRmS2SQDU60A0B9i6LdHpdjkJky66rUc1rOaj4MBoABGmLDyfJk5cvFUiysFlRKQmWhIShKQlKRkAAwA7oKERrWE5xArGuieyPP7R3UcLZPPtiJY7SgOZr3DMwBa76CUGYppcsZzJpwjuTmo8KRkek3TSzWRRlWdItNpyJd0Sz76h6Sh7I7yIwVptNots3FPm4iASVGkuUjXCkUSNN1UDmInkrSNIYnLb6Nje3Thc8qRZVGVKSP3LSodoDaWj1VHIE14Bnjzu8LYbSsSpbplIfialySc1TFGpJrWHXveHWNZrPSWmpJ13mL3UdByAyi3uO6glDtRIOb1PMesd9I5J5H2zrjBLSJLpsiUpJZgDhSAKOOOTfFjBc4FylNCQy15qAL/to1cjOJZtoZg7TCnspctLSPWI9ojwpvQWbIJSUM5JFc24lm7R55RK0UwFNnWi1JWE4UpCQwbR+yW1YxZy3WslQU5OifqQ0JKsxGaUnmlq8wXi2s0s/wCWByA+sPsgls0sAeis88P1gpH8J8B9YaARp8PnDwn8pDEPKuA/0mOhh5nxEdAFlIbNNb7u3iYzPSa71BaZoIrQtooZaDyjo6CLG+giz3pNMoS5YCFf9SZnQu2Ee0z1/tBFz3aiqi59omqlE5OdszHR0Zz+DSPyGz5pJ6uXShc8PzaMned94j+nsgJUs4VTDRS3zAJ9FHmfKOjo0wpceRGVu0i0ui5UWQY1sueddEcE/XOIr4t+ABS6qUHSnRqso+dPGOjomPqlscvTHQJdNnKiZkyqlAHkk7aOfIBotJxckJLp0yEJHRMm7HFaGqUySW3+4EVc60Cb1KQpSSiaVOgsrtJqlJ0cpSI6OiscexZJdILXeMtSwlSFglTBSiPSdgGTuYS8rgllZwqKVFlNmDiAWw2Pa8oWOjOb4JOJcEptqRmbZeEwzOrlKWkA4aqqSKF9M4vbFLmJHbmrUde0WHc9YWOjXyJaRjgjtl7ZbImSlM+cMa1AmUg1FPXWdQKdmMpel4TJ81SQo19NWrPkBoNAI6OhY0rf5Dm3ovrlsCZKHatQNfPzO8SWha5sxFnkB5sxkuSBpk5ySA53bfKOjomPqns0l6YaPV+hfRSXYpTDtTVMZkxqqIyA2QHLDvzJi1t95BC0yUjFNWCQDQBIoVqOwOgqaZCo6Oj0apaPPbt7CpNm9ZZc6n6CPIem3+Ii7SVWaxKMuQCUrmh0rmEFiE6oRo/pHgM+joU20h40nLZl7tu4uJaAMRIA0AevgwJ7ojve8AkCzSHYkOo0MxeWI7JFWGg4x0dHL7X9zrlrotOjlx+q9TVavzTYRogAhIUkdl8Mse0ado8A4oc/GOjo43Jt2zdJLRWzVhyXqS5JdyXqX5+dYJsdlSqrq/1P8QI6OjWJEiykWSWM0nm/3gqXLljIHx+0LHRaIJxg3McVyx6y4WOihCiandfgPrHR0dAFH//Z',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'ข้าวโพดอบเนย เป็นอาหารว่างที่ได้รับความนิยมอย่างมาก ด้วยรสชาติหอมหวานของข้าวโพดที่เคล้ากับเนยและน้ำตาล หรือบางครั้งอาจเพิ่มรสชาติด้วยการใส่นมข้นหวาน เหมาะสำหรับรับประทานเล่นในทุกโอกาส',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content
ElevatedButton(onPressed:_launchYouTube, child: Text(' YouTube'),),

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}