import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Page2 extends StatefulWidget {
  Page2({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page2State createState() => _Page2State();
}

class _Page2State extends State<Page2> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  void _launchYouTube() async {
    final Uri url = Uri.parse('https://youtu.be/gpQerDBY8ak?si=-VgjUtZXoEAGHmE6'); // ใส่ลิงก์ YouTube

    // ใช้ launchUrl แทน launch
    if (await canLaunch(url.toString())) {  // ตรวจสอบว่า URL สามารถเปิดได้หรือไม่
      await launchUrl(url); // เปิด URL
      print('เปิด URL สำเร็จ');
    } else {
      throw 'ไม่สามารถเปิด URL ได้: $url';
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMVFRUXFxgaFxgYGBcYFhUVFRgXGBYaFRYYHSggGBolHRUWITEhJSkrLi4uFx8zODMtNyotLisBCgoKDg0OGxAQGi0mICYtLS0tLy0tLS0tLS0tLS0vLS0tLS0tLS0tLS0vLS8tLS0tLS0tLTUvLS0tLS01Mi0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAMEBQYBBwj/xABBEAACAAQDBQUFBgUDBAMBAAABAgADESEEEjEFIkFRYQYTMnGBQmKRobEHM1LB0fAUI0Ny4VNjopKzwvEkgsMV/8QAGgEAAgMBAQAAAAAAAAAAAAAAAgMBBAUABv/EADIRAAIBAgQEAwgBBQEAAAAAAAABAgMRBBIhMUFRYfATIpEFMnGBobHR4fEUI0JSwRX/2gAMAwEAAhEDEQA/APVHeBUxx4UYxppBVjpNoBbmCaJOsARWOA0gssImBsTcStDmaGlIggsSiGhyBMCVgGEc2QkA615QIWOlo7Cx2o2Vhd31gxLJ0gwQATrS56qeIjlFshysNCVxvQQUy2lyu8PeTj6wDTiK8Sl/75R4+YgLjw3Kb8v3pbeJf30hiikA5NgTpnE3Wm970ptG8xHTa7Xy7kz3pTeB/T9Y7MAF1uKZ196U3jX0gsJLNQAM2Wg6PJfS/MflBRTvbvvviC3dDUwZa5r5NyZ78lvC3p+Rg5WHZt0jNTcf3kPgevMfrD01klAliXZFaoHGVW1edIYm4hySpsq5d1dHksKV51Br8IOUVH3vQBSb2JcsqoyuQ7gBXpcC+6zj0iDiZ7FqzPCCZc1eAD/dzF+Xz5R3D4Vlpus2TcaxPeSW8PmR+vOH52EaoJUkAd29vHLPhPUj9YluTWiIsk9WMMlPH0lzTz/0pnn16nlBPrVrZiJczo4+7cedviOUEJTZaOCcu49jvyz4W6kcfWAcWKven8uZzKH7uZ6c/OB7775khMKk5rBiEme7MHgcedvlGN7X4Uy5i4oChJ7ueBwceFvIj8o1ysf6nD+VO6j2Jnz+ZgNo4UTEZZlwR3c3/wDOZ/n9I6SzLvvtkxeVlFgZ+YAgxYICeIjNbILSneRM8Us08xwI8xSNLK0rQxRasy8pXQ4F8oGogjTlDTMesQSjp15wL14Wjq/COlYgIAGnWAdzDlOpgSYFnDfeHlCg6x2IONVkge7qYcpzhylI01G5muVge7gGEGzQ3WOlbgQrgmGWNTDzi0RxC5DohqIMGABglS+uscuhz6iNYBTDrilBxINOWYcKxHGI0IGtaD3l8SnrEuLIUkOFbE9KwGYLcbxpmHvLxp1EMriSTQcs8v3qeJD1jg4ZNPvJX/mn1t+kclx77/Rzb277/YbObhTUj+ZL95OK/l6wEt6MMtxTPL6ofGnmIJVrQpw/mSvL20+v7EISs33fH+ZK6N7aHlX8zBJPvvvQG67771OOKEFblRmT35TeJfT9IUqSTaXfLvyzwKN4lJ/fCJXdqtKm4JZFGtxV1/xDWHLzQDLpLlUVlNPeOdHU3rDFT1s/Tj3+gHPQOktN0b7Au6KOVN9QeNzpCWTNahJEqWMpAI1UjeVl1BiNitpycOCssVNSam9C2tK6eQjPY3bbubkw15ILX0X5AipT29WaYTMPKpcuVDAEn2WNSvUefKGW26qiiqqgCg6DlGMm408TESZtIcDCXi4w2SQ+OFct9TbP2iPOBG325xRbJ2RMnKJjHKh05nr0EV22Jvc4kS97uyDRgK71BQHiRr8YmON4gywy2RtJe3jziZL2mrCjAEGx6iPPJmPMs74IHPhFpgtoqdGh8cbSejfroIlhprZG17uW9TTVcp5FeAI6Qy+EYBfbFMj82lnQnqP1iswuI5GLbD4gw506c9ULzSiY/tVgWUieoJeUQkymryj4H600PrErZ+JzKCDrGumS1cHgSKEjWkY+bsqbhnOY55ZJIcDSp0YDTz0jPxOFcfMtS5QrqXlZZVjhHSGZcyoh5WrrFHcuANLBhZekdI4QJECEIoP2Y53SwqwiYEk53HWFCpHY441gQRx44rR1jGvpYydbgEQ0Vg88ATCpWGRuC4tDIEPOI4FhbQ1OyEEA11OnIxFnzxVRormgP4Jg0B9YmTZWZcuhFweRGkV05A4Iawmbre5OXwsPO3yhjWmgCeuo45LClaZjY/6c5eHkafusME5qHw94aH/bxCaejU+nOOSpmbx2LHJM9ycvgcdGt8RD8vDNMzVFA4KzeGWal1cfvlHRV9F333sc3bvvv4kWYpN1sScye5OXxqejfrEnDgzACg8W+nuTV8ankDf5wbzpa+I5mLIr0sqzeBPEVtEeXipr1l2l5g4GX2ZoPHmCLwWVJ6sjM2tETllKhFWoSwZFGoelXWunA/Ewy2KZhklgSw6syH/cB3lcfvjDMtM19M5BHuT5dj6Gny6xPwktWHeNZQQ1NCsxbMPK37rBRbbtEGSsryGsLh1p3r7qEhwCd5XpRx/bb5mKPbfaAtuJZRytAdodsma2VTRRGS2ltFZQqbngOcRUrKmssPmw6dJzd5ehJxOJAGZjTzimxW2r0QesRJWDnYqrk0UfCvICGsPhKaxmzrLVXNCFNIe7534mLHYmzTOnJLOhO9/aNYbk4eNP2Lw381n4BSK9T/gRWg887DZeWLZri4UUCjKNRpQDSkVG1JUuYAQoFtaEUi+Mqo4V6/lFbOwQNb1NfRac+usXJxkilCUTL4/ZrPJaWHJFQanmBaMlNw87Dne8PBhWh/T1j0acmUcDy84y22cYAcpIqR+7RXzX0avcbbiNbM2q/Axqdl7drQPr0/SKPsjjZKAhkGY6HzgNnYUvPnKWyhTUcahqkfSK/jVMPN+HK1tenpsF/bqq00eiYSeGFQaxOFCKG4jMSZ5/h88u7Sv+Sr4voTFrsbaqT1BU3pcRvYL2lGtaM9Hw5PvkZlfCuF3HZfQg7U2UZe/L8PEfh8ukQEnRsgKiMvtzZ3dHOvgOvun9I7F4W3nh8xmGxF/JL5DQmj5QQYRXypnWJCNGbcvWJBECUgQ/SOhusQSdyx2FmhRx12X5MLvTEqghFB0jS8N8zO8RciJ3nSONNiX3K8oBpAiHCQSnEjZzBGsO9xCyQORk50NoSDWOYjCZiT7Dij9CPCw6w9khT5auuRrihFPOGQXBgSlfVFZNxEpMzHfaiLNPsip3XZdbc/0gMTiWf72yZmlzVFsub7uYpHClPieUMTZWTebeyDu51f6khvC5HEjX0bnBy92qvvBAEf35DeB+tNCejRDk9l33+SVFHDLpUzLkASp/vL/Sm/P5nlD8smu94gQr/wBw8DjoRaBBy1z3MsZJnvyG8Ldafk3OENyoa+QBXP4pJ8D9Sv5GO699/snoSJCd4xABAcnNzlzZfH1AHy5xC7U7U/pJoNepi0mze5ktMPia3QgWDeZFIwONxFSWY9TDJy8OHV/YCEc8+iImPxglqWPoOcUuztkHGVfvQGqbEVAFv36RV7TxxnTLeEWEWux5ryroaGMjESko3juacI2NHsnZc1B3eZaDQEHU+UNbS7OTVbNnl34VbXraJmx52ImsTVVC0JNP31jnaHEUTMpoRc3set4y05p3l7zLMd9Cq7hkGVhfnakazstQIo55ifRgIzEtJzKO8lkKfC3BhFz2en5XCE+0fgwH5qPjFvDTyTalv+0BWWeN0bAOB1r8ojYw00PzqL/nBOaaG/WI0p8xYgC31jScsyysoKNtSLPTidPrGR7SSEYhQg55gd746xrceDQ0IrzMZeZKsSaVza6mnIRXlpKyHx2uZ7+Fyg0BFedxaObH2rvhmO8hKP8A2nn5GJuKF6016nQRksUe7xRr4ZnwqLH8vjBSpqqmny7+gu+U9i7M4pUUyzrcj3gST+YgV2UZMzPJO6TUDl0HSMV2b2tfuJxpSyNxHIExvcI7FGSu8BVT1GlYxqznCWSXy/PewezzL5mi2bjBMHJh4hyMSsRJDqVIqCIoMDjM1DTepX99IvsHiBMQMuh+RFiPjHqfZeO/qKeWW6+vfEy8RSySuloef4/CtJmFDpqp5gx2XNMabtfgM8rvAN5L+Y4iMXIxQPGK+KoeHOy24F7D1c8ddy3SdDyvFbKmxJSZFUeS80KI+aFHHGy+MKnnAZoWaNK5nWDp5wjSkBWOGOudY6THKQBBglEQncO1kETBCBpCEEAR8ctKTAK0FGH4kPiHprFZly2G93QqvHvcM2q9Sv5DnF7FRiJTKaKKtLq8r3kPjl/vmOURJcQovgCDlAZd7ux595hn+pH5DnD+HkVZVUg5aZTwfDvSorxy2+C84YkMBQy7ihmSveln7yX5gnTy5RP2RKAJIFUVS0puSvqvp+nKJpxvJLvvviRN2Vyo7X4oVEtbBRp9BHnnaTFUUIDQuaE8hGn21iM0xj1MeebbmtNnMFBIW3QawrEyzTLGFhZIWHwpM1URc2YhVpxYmg9OsenYLZeFkIstpYnTjTNdtTwXoPyjK9hsGe9WYwJCK7V4VC0see8I0T7dkSFaYwzPe1yQDwr6fOMbEVXnUV+S5KF9hdp9rSsMrS0UIOQ4mKbsxsc4s/xGKP8AJQikvg5pUBuYFRbnB4STJxbDETcLNSh8JbdYcGGYikStszc4SRKnS8OKUVQMzHyC8bw2GHqR1y+Z8XZJfD9E7RyomdoGxk1CcHLV1qVO8oygDRVJEZjYm1Ztc5W9aN6G46aRpthyzhpTys+cmhJvW1c1c3UwAw6YeUqOAS1WOlb8/S/rCcjpQdo3a433vfqK8eEHlb02/ku5+LArpWlI7gHPdi2t/jGd2fKnOgIll1e4IuFqbhm4RoZb5aK1jyhtOp5rPQOcVbQKa1deEU+Nw9yRenTjFsWHkL2iNiRukGorWptaLDdxaVjIbUlCq2aq+lTxrzjNbewHeruijKai/HiPWNpicHRaVPOtam2kVL4UEk0P5EwcG1tuBP6Ge2FjJOITu8S2RtBM/J/1j0DDY5cLhmMycrkKRLytUkEUFY8rxGCEqaw9liaefERZS8NWkLxNCM2mnZd7chkNVY9Y7ITjNwcqYPEgPqBYiJP2e7QzpNRjcTHYDkHNafH6xVdh8dSU8vQijejACtP7laIexsYMNtIy67sxrcqOK39YXg6qpYmy+fwb/j0Aq0nOM426r7np8xKgg8Y8j2nK7mfMlnQG1fwm4/fSPXhHmX2oYcpOlzBbMCp8xcfIn4R6DGwzU78jNws7TtzIEmb1iZLmmM5hpzRaSJx5RjtGomWwnwohh/OFAWJuj0YuIEzRA5gIXedIvZillCM2OF4HvekLvY652XoEHhZzygDNhB4i5OXodJMGIENDitBIFiLQ1ikLKCviU1XzHA9CLQ6zVjspR5QSd3Yh6K5TIt6JbMTMk19mate8lnob/FotJUsy5Mw3CtvBTqmYVYfEmI+MxJXdlAJ3hYK5FaTabuYcA1D8ucC2Iz4NmIIYkh1JrlmLRXF+FR86w+ikpdRVVtxMBjp3iPrGe7O4ru3mZlLBjU+dGA+oi32m1Ec9I4soLg0KqKs28aXvU3+AjKxs8uj46GnQWhfdmZ3eJOGXLZQAORJrT/pERtvGTglMzuzOnE7q6hSbD96xc9ntmtLlboHePQknRRwqOldIscJsyVL1HezAa5muQTx6Q/C4CVJqVvN14LkuvXgdOsotmI7OLisSz/xMuaA11PdsqDmBUW9YudmbMxMjdmGUqAmkx2uVrbQWt14Rbbe2tMk0Ils6+1lsF5VIqYodr7RSbLZ1QhwFVq3JDGwrWhN/O8BiqNGMm5NuWmjul8V/JSrY1pZVYu8TPREzgrNvcSyCNRoTrELA4qRNSY84AzCxAU1qijwkU0uTGI2PLKz2SYlCikkCwC8y3Kp16WrF5htnGdKMzeIUk+aLc0WvLh5RTqrNK0Vb6mdGq1O6iW3ZlgFmTi7BUcqZYO4XoDmI/SM/2pXGvPkNI3lLVFyKE8ZnSgidtPa0mVIZZTIkl8yszVzO6rUkClRXdofd0jGYntCHVUwazxiDdyGNMoW+RActa8hzhdLD1M6lFXtffb4tm+pXhnlo2bmXtV5bZJylHrataGo9k+0KxJ/ic5IrqBoanX5RlpsuZN2VLOInsz98rK5y5palqKAaVNbVr+KkV67YmYaf/D4hc2hV1vnRtCRFmMW7xvdq/wBOXqDnW5upyWPoPQa+cU+IWnGg5/4iRg8QAvEA1N609OMPmXmAoNfheBTsTdS2MRt7De1SpBzRP2dJV5WdLkXI6RZbU2WShFhqRwseFYy/Z7Hth5pVrLWwOhBgqsXOneO6DpLgaaTtwS1IlyT3mUgMfDRr34mh+sQ9liYZgmzTmeoJItofpFjjNmbvfygWlm5UapztxEBgKGl4z86UXKK158dOBbptZtT2OS1VB5gRh/tgkVwiv+CYp+NV/wDKNlss1ky/7R9Izf2rJXZ03plPwYGPYN56V+aPMpZatup5DgsaeMXeHxMY2RNi6wWIrGPOFjTizTrPNIUVyTDTWFCwz1/LaOqgjmeEHizoVtQsohd3AiZHWeJuiLMLIOkdEuALxwvE3RGoeSONLjgeCM2nOJ0ZHmQyVMLMRFVN2is9WQBldSaq2trcLGD2Ti/6bkn8JJ1HI9RAuNtRifMspsoTEKnjx4gjwsOoNICaxfCvUUcEh/7xSpHQih9YeC8f3SHQuaXMXj9bWPyizh35hFbbQ8m2poREjs+2dcppQMtBzOv5RzbsrKx84k9i1BIXUlix6C4H/bb4iE1MKp145tt/Qu0KtoG6zZJYA8TW/U+kc8IoNTqYCYc04D8K/Nv/AEIZx07LLmOOANPSwjRm7K7Kbbb+JSY2eZ87uQ1Jag5qeJ25DoL1iNL2UzypiSyFCsKVJJG8Dr1I9Kx5Dj582bPZszVzHLvEUvQUvaPY02XPSVLyTZihJSrNo3tKgzNQ2r16RhYheZSnq3y4A4ii275rLkV/bnaHciVlQMFIRkzEKVCknMRrRiPnGS272kmzT92ndS838uWWVcpCnK7cbqL05xO2ti+8mCUrBqWrcgmtC1SaCp68RGn7PbARZZDgMSd6oF6aAg6iIhLoJp0V/kZad2lwjYFZXdnON4plJyWAqSRc0FYzGz56K0x5aEMGIBABIlvQVanJeQtWNz222HJlTUxJZpQaiEpSoIDEFRSlSM2pGgjG/Z6qjGDNlMtg6ggAd4QCFzKToQK+cNUYU6U5xvzs/saVOTtGKWmpptq4TOiYXOcjEEnVlEsq1hzNgPONLs11rZQKAKGIBagFBVoyh2WZU+YCztvmmYklV1VR5AiNPs+9BYdf1jMT0STvx9SjiZ3k0iyVzTU1NjcnjHZuHW5XdY6U0NPxL+zDzYdlAPG/woL9dYjTGKtRgRyFCPWDd4rUQnKLuiMWzkoQQy+IG9ORHMGK3aWwEn2Zb8GGo5UP5Rb4txnlTSKb3dtT8L+GvOjD/kYr+1+LVAUzsigrVUH8yaTRiq8aAakc4bTu9Ys1aFbPG73KnZkvFYXMilZyj8LAsB7yH8qwOxxcDS+h662iF2Qxssz5s+apTDyzVQbAXJNedOUWnaLtPKZ0yIVUvYkUNKb1uAuusdXwt03Hd7lqFfzf9PX9nLSUg90fSM59qB/+A60rXKPiwjQ7MnBpakaUH0jFfbLj+7wyLqGmKG/tuT9I9FbLSt0MPepfqeLT5JltlJB0NRyMSsLPiNiFtzKWrzQ+ExzDvGfJXL6ZfJibawohJMtChGUZc98L9Y7WHGlAaCB7musHZi8yAECWPnDjyusAJPr6xFmEmjoMKvWBmSjwECwI9mO1OsmPrWkczmGgbRyJuRlKLb8ju3E9NRcjgRxB84dz51ExNCKj3W4xa4hQwKm4MZeTNOHnd233T1H9rfv8oYpX3+ZDjY0mz8fnXWhFiORi1wE0FiOYjFPOMpyw8Oh8ufpF/hcXSjDzgVJ0pq5LpqpB23KHtTgaMwij7EoUxbAndNKfBjT5H4xv+0eGDqHGhH1jBYsGRNSaosrqT5XB+TGL9R5WpcCtRk2nE2xYrPf3lUj0qDA4pM+HYcxFVtLGkTcNOH3b1Rr6FqFT8oscJilVHUm6k2PLUHyoYbU1iwnFpJ/D8HmWy+yjTsS6AFURt5vO9F5n6R6lIwfdyO4RjTLlq28aUpcnW1op9h7dkmu8qkk2JA1OsPY/tLJlgkHvWrSiEUBH4m0HzPSPOSqXluNqJy0aKGV2ZaQky4YZWA1spt8QL+kXnY/FLOkk5qsjFG/uABvzsQY857V9scXiAVlMJEoCjmWSSWqajvbHloBFn9l+ImylmZ1Yy2oc5/GoofO1Kn3esPcVTjnbF2/xGu38nac6aUMuX3AO53ZsK2BmMwDV8hQV46xN2N2UbDSMGzgd6MQ5ZkO4mdSqk6buVBpxIjaTJqvyIIjN9osRjJKBcMA6ihqd5hlNaFevO+ukKnXqTjkilZ/L1HRsmugx2mb/AOWxQmhC+pApX5Ra4GQvdqe9fvGNFlqd49WroIYkTpeJkLNyL3pFGtRlYagjz4Qxgi2epJzfv4RRoVEnlktVoVq9Nxlm4M1O0dqFFyAKWWlhXd4inXSKidi2mEM29T5ekMSZWYsbkmpMTZWEoM5sBqTYCmpJhtWrUqOy2ESdym7cbQEnBBtGM6VTrRsxp6KYnbO2hJMxmmZf5yqZb20yiq14XBPWsYntni/4+aiSiTJl1CkaOx8T9RwEQ8uIwwCWelCONOYHoTbrFuCjGKV/NyL2GpvLZ8S57S4mVLzyUuASctN0Ei4ryv8ALpFD2X2a+NxiJ/TVgz8qCn1sI5jpLzWsa5vEaUPlcXj1T7MOzvcSzMYbzfQC31MXMPlclFbvcOtenFyfyN3gZARQo0Ajxr7Z9qZsSksGolrmdeaucvypHs2LxAly2cmgAMfNPaPaDYmfNnampdPekmxX0pWNGs7Kxn0FeVyEpoOeT/lKb9P1hvJlNPh5cIGW+WhF8oqPelNqOtIlGVVSB7F16y20+Bt6RTki4hxZloUADChVg7n0ezQQMcLRwvHXFWCjlBBVgaxJBxqQJAgmgaCIYSCAEIpCAjhEdcgB5I5fKKXtHssTJZoLj91EXl4FzW0cmk7hK5jdnnvJeQ1LpZq8bWPlEjYM0gmWx08IPLz6RH21JbDThOQbujDmnH1EdxC0pNQ19pSNCDwgpRzK3oTGTi7m0wq5pZlt6eUZXa+ApVSIudk7RzqGGvHoeIMTtoYYTVzCLOHmqkMj4fYr1ouE83M8uxrOkppLNRKgy3N8rcB8rQxI2vNxChSMrEZWaviHp+7xqNrbLzDLyNfOK7Y/ZUhSzPlvujU8dfhGZi69SjF0+HB9P0X6VSNSKb4FvhuzSfwy7oEwVapAPp5UEZXbmynZbuQpJyogFCKmhzAUvSvqY9AwGOAotQcoAYeQpblGZ25tJcGWYy+9lsd2lP5bUpQjgLaxWrWtGVLfYTGUnJxkU21cPIw82Vh+6VkmKMrtQkMVNxW1SRrTjE2biUbDNhpkh5CyjllvUAuRUkhSBUaHrc1jGbQ7QT8RNBWWEBsMt2KjdAzm4FqWiz23tszJMtLCaooWADKRcVavhNOPnEOhO0U93126gvRkOXtqfImLLVw1zxDKRwynX4xYbW2hjEysxRVmEqMtS1VpWopYXF+sUGyMyzGKS1SYARnsQASAdRbXWAn4ljMRGLccuU0BJINVIF/CDWLboxvw697AqTNFhZsyXKearAsBnJYVDUuQafCIsztzPLBxIllCKG7Vrxq0ccsMK6uMtQa8SATQfWsF2B2RNMzd35JsxYUApcEV1PC0VctOEZVJJNruwcoSnG1yVN+0VpZKDBgPoQzmnyFYaxTbQ2hRZo7mTqUUFQR71bsfP4R6CnZeSZgmsimYBQMRoByGlesSdpz5UiWWew0A9pm4BRxJis8dolShZ9efQiNKMXzMpg9kLLCoq7xsvTmfKI+K2eFXKbsrsCY0OyZBDHEzTvEbksaSx1PExCk4cznooqSxNusU87vvd8TQppMLs1sITXFRYXMem4eQFAUaCIexNnCTLA9o6n8o7tzaiYaS0xzSgr/6j1fs7CeBTzT9579Ohk4yv4s7R2Rifte7R91JGGlt/Mm1/wClaZvjp6x4zJfTLwq6DmD94n76RK7QbWfFzmnMT/MvLr7BT2P3zMV6tWhWxJzL0mDxr63+cOnLMwoQyqwbDL4bgb6dUbxL6fpE/Z1ha4TeHvSX8Q9PyiFWo3eryx/3E/fSLDZO7Qi+XfT3pbfeL6a/CFvYMfnYB1JCqWXgRxBuPrCi/lysSgCypeaWPATrlNwPStPSFC8jJzI9iJjkCTHEaFXOsFWEBHIcBiVqQwWrHBDtIBhSJatqQnfQ5HQ0DWOExFybBZ4GsCTHQYi5NrETamEExCCL8IyOzz3bnDt4TUyz9VjcExl+0+AqMy2OoPJhpDIM5oYwU/uZtD4GPwPCNhhJ1PIxi8PPE6VUgZhZhyaLLYeO1lv4l0rxERJuElOJKWdZWaHHYINcRTYjCtqpo3yPnFsmKKkH2TZhyJ8J/KJDSlcVHr0MWZ06WLhlkiqnOhK6MnNw6zTQkypvMaV6cxFVi8WwPdYiWGpxIBDU4jgY2k/Ag6jyPERQ7Q2NOqWVs4p4WFaeUYVX2fiKF1DWP19C3GpSqu7dmYva+DlmrS1EulSaaG4JNOGgMS8Bgu8kykKgqGYg3AoQCaEaDUw/MkMpyzEr8vj0iNNwGIWWq1HdKhAoTWnGtRbShApA0Jtp5nsHUpvRWIe2sdhpCgsJjZiQoFakDUjMRu14wxs3Zk2Yf4lQrOmZpaNXKaqRlBBtanqIzW1WbET2mEUAso4Ki2AFeFI9F2RKYYNzLrnyNkI4HKaWizUfhpNbvcX4bMrsqfMxYnhwoXu90KKAG9eZJ01Mbr7OpFZYliu7UtyUVtfmYwOxMO4NEJGax4VB59I9l2Bg0wmFFwTTMzD2mPLpoBFetGM5vM/Lv6IdVeSFluwtp4oSlJIrTQDUnlHlG2tpzp2IzOfD4VHhQdOvMxq+0W3ASamp9lRf4CInZ7slNnt3kxSi9dT6RXwylOTcY3vsHTSpxzTD2R308CWoN9T/AJ4R6DsDYyyEGhfieXQRI2XsxJK5UHmeJhbW2tKw8szJjhVAuSY3cD7MhR/uT976L99fQoYjFup5IbfckYzFrKUu5AAFSTHz/wDaL2vbGzciEiSrELqKzFNQT7vKHu3XbZ8axlrVJAYqw0Yk+Fj7vTyjGTBWtbE7rdHHhb1t8ou1Kl9EDSpW1e4aHNbTPce7NXUev6wKtXpn092av60+sBIRmJoNdTwWYuhr1iawQGp3i5p7qzFFj10+UKGhYDDM5BG4CQwJ9mYPEAONbxosIQlO5UVIZ5ZN6mv8xB+E0+vSKTCBphBJoWsPcnS9PQ0+XWNFg5Zdd0UYkvLH4Z6V7xD0a/xaBbOtzJAXFHelOhlm6lqlqNeh8q09I7EiTgXmAPKmlEa4WnhJ8Q/6qwoVnZOVHqZMNohzVMdzUhOxivcakGWvBVhmUKX1gwIJMhqw9JaE7Q0hMGRB5m0A0kzlYEtHKR2BCshVgTBRyIJQNYZnyM6kc4frHI5aakmCxinDzs/sGzjl1iwxaEUmpfLe3EGLPtDgQ4JpYih/IxRbDxBXNh5moByk8V/xD7KS6MC9jUYDFLMQHUEXiQuZGBGporefsN66GMxs6f3M3J7D3HQ8o1LYk5AFoPxNYsF90EcKwqn5ZWbsFU1jdEgbQCgd/llsTSmYa1oPKvCsS+6B0jFTsKCHE7e/pTz+KW5rKneYPH+7pAYfaM6UylnO43czxwDGnczwOCtYGlt4/hi7DFf7IqSw/JmyxGARxRlB+vxirxXZsFCiOVU8CKiI2H7WFQe+SjJMEt8ui5juOa+wwIvwNeRMWi9osPVgzhSjBWzbuVjcAk2vW3OJnRw9bVpX9GQpVqei/JlJf2eUrvKYnYfsjOTwTAtiOlCKaRqpe0pR0dT6iHf42X+IfGEv2XQet36h/wBbV2/4Y3A9gyurr6VjQS+z+WWZYmHKTU1FaH3eXlE6ZtaSusxR6iKjHduMHL1nKTQmi7xIGpAFSY7/AM3DK916tkPFV5fwS9n9mJEo5suZvxNc/wCItmZUHACPM9rfautGGHlM5C5hXdDDpx+XGMDt3tnjMSTmmEJQMqpuh04gnUn15RZh4VJZYL0AcKk3eTPVu1f2j4fDBllnvZgFSqkWFaVY8BHjfaPtHPxcwtOaqg+AeDI2jAcSOfnFXKBqMgLUuvvS21Hp+UPGQiDeOYgGijjLJ0Y9ICU3IbCEYgS1LGlK03H6rqrVh0y0XxnORlVgNKeySYamYk6UAVdQNDLbQ9afrAEZdbgDK3vS28Len6wAwHEzWax3R4SBYBtVaJGCl95ZrB90n8E5fCfWny6w3/D1s3RG8j4GiZs6XejWzHu392av3bjzt8ohvQ6xYYORWzbpc5W9yenhYedPpF9gRUg+HOaH/bxMvQ+TAetucQygK5n3c25M92al1cD0+kQp+1Xm1WSCM2Qs3BnQ6gEVHCEth2NLM2XKmEv35lFrmXmAyt7QpX8VT6wozP8A/EmtfPSpJpc3JqbmFA548zsjPbppgxNtChRXT1GtaBpQiDUUhQoZHYU97BKOcKY/KFCgr2BS1GixhVjkKIDOZoRmQoUA2wsqOKY7mhQo5M6wDqCCDxjFdocMZZzL4kNQea8jChQ+jrdC5DzqJ8kOLWr1H/qLHs7jWZaMd5TQ8jHYUDV91S4h092ifjkC0ciqjccc5T6eoP0in2hLC1L7wSkmeP8AUw8z7tjzZSfOzc4UKOe4KIk+Xlr3u8Eph8R/uSX+6mdWGYV4+PmIiYuRZhO3jLIw2IP+pKa8ib/euYV/+3SFCglsQ9zM43BukzWkxXEtm/3UFZT24MtmESEJbwVBYGfJBPhdLTpTe6fzPSFCjr6BETESa3l3ovfya/gP3stuQ3v+R5RDm4f/AE/w9/Jr+BvvEPLxf8ukKFE3IK90ymqXoO9l9ZbeND8fn0hybs4JdiQoOeWBqVIqynkL/OOwocgHuQmnmgEsZVyh1pqRXeBPrDRSxI9gZ16y28Sn98oUKJ4nAtLymuoUV85baj0iVhZFCym/d/OS/PqPyhQoFvQknS8JSoa+Q5H96W/gbzH6w4JYJKg1ZlKvXSqndYdaQoUJm9AoonNs7vDmmsWNrcKgU0izwmFVRRQB6RyFFWUm9xySJoEKFCgST//Z',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'ข้าวซอย เป็นอาหารทางภาคเหนือ แต่ออกหน้าตาไปทางก๋วยเตี๋ยวแกงของแขก น้ำข้าวซอยส่วนใหญ่นิยมใส่ไก่ หรือเนื้อ หมูก็มีบ้าง ใช้ซี่โครงหมูก็อร่อยกรุบกรอบดีนะคะ ทานกับบะหมี่เส้นแบน ทั้งบะหมี่ลวก และบะหมี่ทอดกรอบ เพิ่มเนื้อสัมผัสความอร่อย มีเครื่องเคียงเป็น พริกผัดน้ำมัน หอมแดงซอย และผักกาดดอง บีบมะนาวสักหน่อย ตัดความเลี่ยนของกะทิ กินร้อน ๆ อร่อยมากค่ะ เป็นจานโปรดของใครหลาย ๆ คน ด้วยรสชาติที่ละมุน ทานง่าย และอิ่มท้อง ',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),

            SizedBox(height: 20), // Space between buttons and the next content
            ElevatedButton(onPressed:_launchYouTube, child: Text(' YouTube'),),

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                  
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}