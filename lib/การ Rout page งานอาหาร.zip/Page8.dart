import 'package:flutter/material.dart';

class Page8 extends StatefulWidget {
  Page8({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page8State createState() => _Page8State();
}

class _Page8State extends State<Page8> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSExMWFhUXFRUXGBUVFRUVFRcVFRUXFhUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGislHyYtLS0tLS0tLS0tLS0rLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0rLS0tLS0tLf/AABEIAK8BIQMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAADBAIFBgEHAAj/xABCEAACAQIDBAcFBwIFAwUBAAABAgADEQQSIQUxQVEGImFxkaGxEzJSgdEHFEJiweHwI5IVFjNTcoKT8UNUorLCJP/EABoBAAMBAQEBAAAAAAAAAAAAAAECAwAEBQb/xAAtEQACAgICAQMCBAcBAAAAAAAAAQIRAyESMVEEE0EicTKBobEUFVJhkeHwBf/aAAwDAQACEQMRAD8A1PtQOqPmZI1ydBu4mSNG624c4uoZNCLr8X1nnJnW0O0usLKfnCnqxFW4r4c40tYEWbQxqQpyo5Op3cBOvTJ1vpygDjBub/zJJUZdd68uIg0Y7TRm3aCGpYYb2Og4fWAapxXfykgcw10PKMmjNDprh+qBpz+kYpIALSmNaxsdDwh1xV98pyEoaqOLkXuIuKhQ9XceEMuEap7g+ks8NglpanrN5CMKFwFMgZ6nyE7Vr5rmBrVSxuYKrUyoT2QqdugNUZbG1b1H75xGA4RZcQCSbbyfWOIVMhJWxSS1QTIsZPIpOmvdInZ1U+7TqHtyNb0ipMxGoZ8pEbGzq240ql+eRrekUfDupAZWHeCI1NGOZReRdOUIuGdjoh8I1S2PWP4fGFJ+AWV4SfBZcr0fqneQIdejnN5ThJi2jz7pPXZHpup1BuO8Sn6abPFRFxtIdVgBUHwt2+nhN70z6PIKIcN1lN5kcLtAU7hhmpPpUT/9Dtl8T4/TIDfgwKvafZ5otq9GirB6XXpPqpGtuwyuqbLZTqDKuDXwMpJlUWnM5jz4e28QS0czBRxIHjEGN19lvRP70/t6o/pKeqDuYjj3T3PDIqAKoAA5TN9FcKtDD06a6WUS8WrH60KPipPhUiYqToqQGKbpl0SoY+kVZQHAOVx7wPfPzbtzZVTC1no1BZlO/gRwIn6tFSeTfbdsYFUxKjUHK3aDG7QOmeOTk7afRBj9K1NjVVPVsy9hgcQhUWZSB2iZPZ+2sRT92q1uR1HnNBhumNXc6K3lPN5R+x1bBIQtyOO4QTuxN2FuUuE6Q4Z/fo2PcIZsZgnGoI8ZtfDQL/sU1EA747TGm75RpaeCvcFvEw6Phgbi5+cZV5QLE6OHANyNTwkq9An3QS3C36yzGMpDcusn9/J3AD5Q/T5BbKwbEqVLFrL6x/D7KpJbN1yPCE9qTvM+vCpJdIGwz1tLDQchAEzpM4qE7v2iuTZuiEq9uLVdfZUULE7zuAHaTpLkMq9p8oSmGfUmw4wxkk6W2Bx8mf2d0Xawzuq87a+cuaWwaFPVrue02HgJPE4jgNwglqm9yQROX1HroYXxStjRxXseTFKo6ihR+UAekmMdz9ZXFr90IiC155/8w9TJ/S0V9qC7H/vQ4GRbFcDYjx9YoQBqDIe2PGCX/pZo/if+Ae1F9FnTCkXW0E1XW17HkdIote2o0jbFKgGYdx4j5z1fS+uWdUu/3IzxKPZCoTFKrmCqF6bFb/uOEmuLVtGFu0fSdC9RG6lpiSwOrRUbWpZ0ZTxBnlG10ak5HCe0YzDEi69Ydn0mB6W7KzgsBrLWnsik09mV2Rt1sO4Zesl+tTO7tI5GbLC4jC4wZqdgx3odCPlPMqyFDYyNKuyHMpIPAjQidOLNKH2DKCkeiY7o2u4jWVKdGFVlcHcwPhAbO6b1AAlcZxuzDRh9ZYnalOpb2NUX+FtDOxTxzRLjJM9B2ditAOyW1KrMVszFnKCZd4XHjnOKSo6EaJXkw0r6OIBjK1Ipg5aZH7TFDYGqDymnZ5hftMxpND2NMFmc2suunbGQGeH5Z9Lr/LOJ/wBvzE+jcJeAckbqksaprB00tGUE8NnamEprDoJykukKBAYIixyiIqkZpxkAcpmMI0TUwyvGAPK0IGiPtwBqYxs8ipc7lXee3kI8dsVsZUcToB/LCCq4i+g0EBicRfsA3CKtW5yc8nwh4wHFqXNhHKlXKMv8POV2Bq3Yd8dxg1AHP+d0Dk4YnNAluVCLk3ueN9OQ4Qyrz8uyKYlWXfrrw5TqVjafMZMlzbkdijrQzUawvA/eTbSQV73BgqgtpJNt7QyiumOUMRzhxUBlbTMPTbXfGhkklQJRQ7xhUe0UJhVOk6MOaWObcfuSlG0H2kmannG9fQmVK1ucu8MwItvB0I7DM/iVyOyngSPlwPhPflNZIRyL5IwVNxHaNUjVTPsZgqdcEHqPz4HvERSpyjVKteCGSUOhpwUuzzLpZ0fek5DLa+oPAjmDMbXw7Lun6GxNGnXQ0qwup3H8SnmpnmHSzow+Gf4kOquNxHbyPZPRx5VJaOSUHFnn3tCJ1ag7pY4jC8xFHwsumhR3CbZrIOrUNuR1lvhOldUe8B3zMrSkgpjcmY2+H6eOu9Y2ftLYD3POefopka27dNyMbTFfabVbRUHjKPGdLMTVN7he4XPnKJKZO6Xex9k3YF93KZ5HE1Cv+I4j/dfxnZsfuFL4J9E95+QUjZVMEvKJ1sAOBtLgreAdJ51BTaKpaDjiDPsj8hLBkkSkWhubE0LchDq5k8k4VmDzZ3O3OQYsfxGSAnyJczA5M+w+HLMFGpJtrL/FWo0xTU9pn2w8OAM1tddfy8f52Sq25jRcm/8AOEq1whfyx8cbYDEYsCTwNFqhudBKjZ4NVsx3X07e2a7AqBacsFzezqm+KEMDUu7heAsPGM4nGHQcb6j5b5S7KxQWuyt+K4+YMvamHBANr2AF+NhDn+rE4klqVsXrObSNIc59VWymfXnzmSHGR1xegjC2s6rAjWQEigvJXvQSbjlIX1nRIEmZqxkMrVk6dXW0XRCdwhaaysMWSTVJk5OKH6DSo20/9U9y38BLSnvH81lhV6P0n1bNmO8huNp9Pg9LL2eETk9xKVsxoeFSrLvFdFD/AOnU+TD9R9JSY3Z1Wj76G3xDUeIk54MkO0WjkjL5HqGI4GOVKaVUNKoLqfEHgR2ygo1pZYXEcDBCbTtAnG1Rj9t9FTTYrvG8HgRzlBiNgHlPX3pCqmQ7xqp/T5ykq4Ecp2qerRwzi4ujy2psNuUD/gTcp6g2zxynw2evKP7jFs83o7AcxTbWxqlKxt1ec9XXBqOEliNnJUQow0MyyMyZ5BgaIGtpocG0FtPZJw9QqRpwMLgq4HCBysoP5zPp37yOU+gtAo3NAaTrLOJo0IwkRQJpyBpxi0iRAYXKSBWNZJw05gioSESnDBIXDr1h3jyhSMWlLqU2Pwrbw0+s8627iS7imDqx17uM3eNrZcK57Af7jPL8BiPaYt/yr5k/tD6l9fY7MC7ZrtlUwoA4CXlKpKjCjSNe1tOfG6DPZnukFIpWY8Ccw+ep87y62DtQ1RlNtLa/XzgcfRFRbW1G48Zm6q1KZOUka3003bvWMnTNVo9Cq0AAeIO/sEWSjYacO2/hFNgbY9ooR9G9Zc0gOFvTyiZPSY8q0hFOUdMSUQYpkPe+hG6PVbDUkDtOkRqY+n+Elv8AiCR/cNJxL0Ci6ZRZWNU8OB2wn3UGKUsa2XRAO12A07luZm8Z0nrZiiZRrvFz6yy9Lig9rQE5y6NnTWwG79pBes1kFz2bvHdMVh6lV/fqM3ZfTwmp2Q5UTrxSi3SVIScK+TQ7OwOU5nILcANw+plnnlTSrxhas9SFJUjmY/ecIB0MXWpJipHAUW2ejatd6PVbiv4T3cjM1Tcq2VhYg6gz0P2kptv7KFUZ10cDfz7DOL1Hpk1yh2dGLLWpFdgq+7mIxj6YuGH4tfnxlLgK+us0NNc1MjlqP1nPgd6NnjorGSDKRwpIFJQ5RUrPgIcrPgsKMIbX2UuIpkEajcZ55iKDUmKMLEH+Ger0hKbpVsMVkzoOuPOUStBi6MJ7QT6ffcH+Az6LRS0ej10t8tQYen1hedZgRaQwR3rfd6SfEnZMrIlYdlnMsbiawIWfZIZlnLQqILBWkkNje0mVkKr2HzHrCkFdim26/wD/AA1Dyo028GW/rPK+iWIvXqdtvWerYij7RDRvYVKT0b8iVyKf7sp+U8R2H7WhiBnFtSrDkeIPcRBOPKL+3+zsg6Z69hW0jBMrMBiLiPoxOg1J4Thix5I5Ve0Q2ithcjXlxmjpYMILnV/Id31iOJwuaV9pvsRSSMS1TEE9Vgvcov4mOUExLe9XqH55fSXw2eBHcNhAOEHFjckUeG2U+hzMTzYlvWWlOjUA5+RlvToAQy0oVBr5FcjIbVxjpdSCLjQ8DfkZU4Onc3noeK2elRSri4P8uOUytbZDUHsdVPut+h7YmSLWx4TXQbBUd0vMILRDCU5Y04+NUJJlhTeMpUlfSaMIZ2xkQaHleEDxVTJqZZSFoYDyYMXBk1aNYKMvtygKdbMNzesuNjtcfIxLpYv9PN8JBh+jDZlv2Tz4qs9HS947BJWUsyg6qSCO6TImV6QYpqOMqEaXKkHhqouDLzZe01qi25uUSOVcnF9nPPG0rQ4VnwWEtOhZdEyIWGSRAkhKRAQ+50/hE+hp9KWYVKxWrTysGG4xtTIV0zAiRlExIicvIYWpde6SYQox8TPpEwZeYx12itZtDDO0XqHqmC9jR7I4g3TMOFj3cD5gn5ief9PaCU6y17WWvckgaLXW3tVPK9w47HPKbnBVhcoeNyPDrDwF/wDplbtHBU6ivhq4/psQc3Gm4v7OqPEqeYJi6vZ1xutGc2DtUMLZgSO2eh7DoWQVDvYadg/eeVYfovUo4xKYJX+oqsN4KE3JB4grqD3T2MaCwkOMVK0NNuqYHEPFiYaqYIiUsmSVRCIJBDCpMAMghVWQWHpiOoitnMs+r4ZailT/AODzENlklEfh5BZQJRKkqd4hQI9tOnub5H9IkJytcXRW7VhqUapxSmY2jS8GIwwkgZASQlrFJgyYMGJGpUtA5Uair6Rvemw7DJ9Cwfu4Y8bSn6UY7IjNfcCfCaPZCMmHQP75UFuxn1t8rgTnw/VlcvBaWoUYfpBtBTi6tNxcXUf/AAWK+xel/UpksnMb175bdKujntC1ano51I5zNbM2o9FsrdxU/rOTLGpNvr9gQmmqRtti7ZWqArEBvWXVphquCDj22G372p8e9ZabC6QA9Spod1z6GXx5KpS/J+SU8d7iaYCdtPlN9ROidaInLT6StPo4BRROiL7NrZ6SP8SKfEAxoiKYVTq1LcDGGgcUOPLyhlNwDAvBgLiAcGNmCcwMwm6GBHu/MxqqYmHuD3xPkeHZWYpipuDYjUHkRHcQBiKXtFAzDQr6r3cR8uRiWLEUweONB8w1U6MvMfUcIr2dEXQ1s7FpmpitpkJFOqd67wadT8tyf+J7LzYFf59Jk9q7ODr7eh11bVl+LhdeTi27j4RfY+3WpADWpR5fiTnlv/8AU+URryVcbVo1dWLEwlHEJVXPTYMvHmOxhvBkGETlXYlHQYVDAAQiNKJitDtKNpEKZjlIy8WIw8+nLzolGKCxi3Rh2ekp6VWXVbcZiNm7RDAazi9Q6kmWxq0zSKYem0q6eJEYTEQRmFxLNWhA0rhiZ1sUJX3BOI+1WI4vFWEUr42IoGrkgGyA9Z/0UcW7PGTlNvSHUa2z7C4X7xVDsL0qbAkHc7jVU7txPYLcZpa9TVVvqbk9w3wGGprTS9sqqNBfcN5JPEneTBbOYuWqHjoP+IlsceKoTJLVjpW8zPSXo0tYF10cbjz75qBJMt48sakjmTo8hwmMqYapla6kH+d4mhejTxYz0yErcRuD/vLzpH0eTELe1nG5hPPW9rhamVrgjjwPaJwyg4WqteP++TphPl32avYu3mpN7KqCLGxB3j9ps8PVVwCpuDMLSr0sYoDnLVA6tTn2NPtnbSq4Sp7OoPoRzUxseXh3uP6r7gnj5fc39p9KT/M1LtnZ0/xGPyiPtS8C3RGrmwdE8ky8/dJX9JdGZr7Pr/c1B3q7g2IP4r3075pbSy6FfZBhF8KbEoeHpGGEUxD5XU203X/T+cor8gDvANGHgHiswpX3RCm+pHOP1pWYjQ3kW9jxBYkSpxIlrWMQxCzWXQHZm1nw7adZD7yHce0cjLjGbLTEr94wrAOfeU6Bj8NRfwt2+u+ZqusFhMZUoPnpsVPkRyYcRHpNDxk10OU8S1J/xUao3jd+zA/MGabZO2Gq6VKTA/7iKcp714fLwg8DtuhigEqf0qu4G9gT+Vj6HziO1tk1EN2UuvxLe4713+F/lJuPkpakalUuLixHMa27+I+c4FmNw+1KqapUzgfFqR2Bh1h4y+wfSVHpXZOuAobjb4jz9YnFoVouqcapyqwm1KL+647ri/gbHylnTqDmPnp6ykZsSURoGSBg7yJqSvMnQDbGLFOjUf4UZvAEzwfZnSN6GVXBbTU8R9Z610rxgZRQBs1S4HcBczzDH7DuTcXMk5wbqZfHCVaNRszpFTqDqsO7iO8S3pbRHOeUVtlMhuCVPh5y72PhtpPbJh6lRfiIyL/3GsvnEeC942PdfiR6ENodsG+0Yvszo1Waxr1FT8lM+0buLmyj5ZppsBsunT/01sfiJzOe9uHcthAsM32Byiuitw2AdzepdR8H4z/y+D17Bvl9h8OABoABuA0A7vrv5yYRUFzYAfICVuMxJqaC6p4Fu/kPM+toxUdIm3e2Q2hjPaHKvuDj8R+nr622Dp5UA7PWU2Hp3YDheX6ysEQyv4OiEWRESxu2KNEXdwLdspaXZEsil5Tbd2CmIQqw14NxBlLi/tCojSncngSCFPzlHjelWOc9XJltpkOYjvk5uLQyTKXauFq4KpZt19G5iaLZm1aWKpilW1+FvxKewzIbZxlbEAir1rcuqR3c5UYPHikbXYHhcaeM5pYbXKHZ0Rl8SPTf8sj/ANyJ9Md/mNuc+kOEv6P1ZT8zffZ439CqL3tWYXsBcZE5aTT5phvs0qi1dLW6ytutfMDrbhum3npR/Cjil2RZovi0zKRbujN5BorAAwlTMuu8TriLUTkqFeB1H6+sacxL0YTrCIV0uJZVRFaqyMhilvbqnh6QFaO42hfUbxEM14LLQdiWISJ1FljUWK1ElIsoV7pLTZfSStQspOdPhfWw/K28enZEnSAYSvZjWDF4PFan+lUPE9U/3jRv+rwhk2DUS5putQEbj1WIvfeLg+AmM9nGcJj61L3KjAcgTb+2BwG5Mvq+At76MvaRp/ctx5ztCk6/6dRgPytceAg8J0wrLo6q/b7p8tPKWNLpFhanv0SDzAU+ehiuDDyPqG0sSm6pfvUfSP0tvV/xJTbvU/WRpYzBtucjvz/rpHKf3Y7qi/3D9YVYroQxCpWYM9BMw3MrVFPk3bI4Do9haZJWgLnU5qld9e53Ilygojc6+KwwrUh+If3L9YV9gWBw9AL7iIvalNFPiBeM+yZt5v3kkwZ2hTG7XzPkCPOAqbW1so/ndr+kbYB9aAG/zgq2NVd3WPgB3mVtSuzbz8v2nF/n84TcX8gtE6rFzdjfkOA7hz7TIPJiRfmdwmpIF2TwtREu7sFA5kCJ47plQT3LvwuoJHjMdtHaDVcQWVuqFYKtxY2vrqOMjRUsQTo2moCEWIPbJub+BHG3sstodI8VX0p2p6+7a7Mp3EEynNCuzXqWJ/MBp3x6mrhCVFzpe4ItvuVsTD0sVVUlSc4ub5iLaa2s2sW7NVCOHwjhb5UJF+HI8ADH6bMRpZVN7sFAJ42h6FNKgOVcliwKkDUkXupBkQPdLAAgrZeuvCxuIOgldisFT10sCeWuo3i3CUmO2UrjhfcBqPnrNX7Jc2pzNppderlPb3xfE4Qi4A1vckA7r8CIqbW0Ewf+Bv2+M+m2+5j83gZyU96RqQ59m4UVa5XiFNsuU+83bPQC0826DhaeKLe6HokGzMwzB89rEX3A6zfY3aFOl772+TH0ErHa0Rn2MEzszOL6c4KmSDUYkC9gj87cQOYiJ+0KmXVKdCo2ZlUElFF2NhfUnyhoFM1GMS4vy/n0hUe4B4Tz7F/aJVswXDLYXtmfeA1gdB5TUdF9qe2pZyLA625X107t3yk2vkNNFpUWLVBHKggWWSZhCqkqMdhiDmXfxHP95fusVq0otBTozua8DUWWmMwOuZdD5Hvlde9xxG8QpllKxOosWdY7VWLMJaLGA2kg3MXncs6FlAklt2+ohEpjs9INRDIsIAtOj2HxjdKke3ygKaRukD/DAYZo0z2+AjaKf5YRemYygjoUKq/zUwyfzhArCoeQhAFUwq+PpBLDIIDEgJmelW2bXw9PrMR19SLLyvbfDdJ9v+xBp0/9QgEsRoik2J7TMbRsdM51Ln2mZw17C998jOXwEtMGwugzDW/WuthoNNRCUKXW0B4XuqMpsd41gMLTYZTYlVNj1la5toTcA74aozBVY5QrK1j7NSRx1sRfdJUBhlo0mVgVKrlYAhXQ6NrqIdEBsQQLaZc++66EhhrAqzF2UZM1mFrNY9UEXG4fKGu9luDe63CkHLe4v1hMAYFFxe1mzFTplNtLWnwqvlZHAz62cqQLDcGt6xbNYlSWDZUYkqhuA2Xgd87hcay5yHuVYjrA3tY6X1m2jB6qFSAVte92B0IIvoW36wFdhcgqQN+i6HMN4IOsbWszBb3CXU6EGxO/QjdI4gOHBY6W6oyoSCG533Wmo1lb/iycz/23nZbZan5PD959BSMf/9k=',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'ซาลาเปาไส้ครีมเป็นขนมหวานที่มีแป้งนุ่มๆ ห่อไส้ครีมหวาน ซึ่งเป็นที่นิยมในหลายประเทศ โดยเฉพาะในจีนและประเทศไทย โดยทั่วไปซาลาเปาไส้ครีมจะมีลักษณะของแป้งที่นุ่มและฟูเหมือนกับซาลาเปาทั่วไป แต่ภายในจะมีไส้ครีมที่มีความหวานและนุ่ม มักจะมีรสครีมจากไข่และนม หรือบางครั้งอาจใส่กลิ่นวนิลาและเนยลงไปซาลาเปาไส้ครีมมีหลายสูตรและสามารถทำได้ง่ายๆ โดยใช้แป้งซาลาเปาหรือแป้งขนมปังที่ผสมยีสต์และนมสด ส่วนไส้ครีมก็ทำจากไข่แดง น้ำตาล นมข้นหวาน และแป้งข้าวโพดเพื่อให้ครีมข้นหนึบ เมื่อทำเสร็จแล้ว ซาลาเปาจะถูกนึ่งจนแป้งฟูและไส้ครีมภายในจะร้อนและหวานอร่อย',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}