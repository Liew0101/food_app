import 'package:flutter/material.dart';

class Page5 extends StatefulWidget {
  Page5({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page5State createState() => _Page5State();
}

class _Page5State extends State<Page5> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEBUQDxAVFhUVFxUVFRUVFRUVFRYVFxUXFxUVFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGi0lHSUrLS0tLS0tLS0tLS0tLS0tLS0tLS8tKy0rLS0tLS0tLS0tLS0tLS8tLS0tLS0tLS4tLf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EADkQAAEDAgQEBQIFAgYDAQAAAAEAAhEDIQQSMUEFUWFxBhMigZGhwTJCsdHwFOEHFSNSYnKCkvEz/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwQFBv/EADIRAAICAQQBAgMHAgcAAAAAAAABAhEDBBIhMUETUQUikTJhobHR4fHB8BQjM0JScYH/2gAMAwEAAhEDEQA/APaEJUKwQShCECBLKbKJQA6USmyiUAOlEpsolFAOlEpsolFAOlLKZmRmRQDwlUedLnSGPSJudGdK0A6UJmcJc4RaAchIClTECRKhACISoQMRCVCAESJUJgIhKkQAIQhAChCUIUQGJJSEpJUxDpSSmyklAD5RKjlGZKwHyiUzMmlyAJcyTOoXPUL6yLGWy9MNVZzsYOaG4tVvJ7Do0Q5ZfFuP0qFiczuUxHdRcQ4oKdNz50Fu+y8hx3FjUrXuZ97G5nkq5zdF2HEpPno9Pd4zA0Y0Hq4/YKaj4xYRJYPZx+7V5QMXJgbd/oVOcWSs8szR0IaOEj2PCeIKL/zZe+nyLfK0WVARLSCOYMheK0sRYeogg2OvtfZauA43UYZzR1Av8hJaleRT+Hf8Weqlyjc9cngfFVgHnMOehHwtR3FWOHoN+W6uWaL6ZjyaXLDtGoayezEnmucdxC8alW/OsqZ6qMeiMcEn2boxg5fCfTrzrZc/SxB1U7cYVR/jZ3bLXplRvoWTh+JRrorlPHsO/wArbj1eOa7pmeWGcfBaQkBSrUUiISoQAiEFCYCISpEDHNSpAhRAgJTZQUhKlYhSUkpCU0lIYsppKaXJpckA8uTHVFG96gqVI1SbHRI+osbi3E2sbLnQFbxGIsSTYLy3xHxXzKhkmP30CpnMuw4t7N2r4pH5SByJBI/USfZKzxQ/k1w5jM35sVx7WWDgfY7fClpViNFmlm9jow0kf9x1tfiza7XU3Nc2QLhzT10XLYjw471GjXYSdnS0xuLSiniIdBME7RP1VnDVg5xGig87XaLoaSD4Rz76NaiSKrbcxf6j7qfCY0St+ljHBzmETtfl1UVfhDHQ/IA6JzMMR/47qMpJl0E48FPzR+IlSFwsQ6CqHE8PUpkHVuzo+h6pMPjGGLwT8KumaVKN8m1hsQWn16ayP2Wjg+Iggw423/RY9OqSIkSU6pVkBrAGgEH/ALOgiSTtGwVW1Mtl4rk6vh+OcXSYJ5bxubbrUOMmw+q4qlUNsw+4/wDq0aWIdFjA1Mz9FFtGfJo1L5kb7sURoUHiBG6yP6qdPkaKscRJVe1MzSg8bpo6bD8Wb+ayv0q7TdrlxZq8/lTYPGEjLTfBmevwmn4ZjzyhHldnY0eJ1PU0Py5XWMAyOV+a1+EcQ80EOIzDYCLcxzXHUHPJmZaRf95SVeKsogkVcpiNSSRyUsOseOfba9jnT5Z6C2q06OGsajXkOtlS4jxMUjlgFxE3Nh3XGUOPZhT8uoDlzG+xteIWthsj/U8EuMySdZWqfxGUofKqZFRR0WBxfmN6xflrFlaWRgMUymCHug6wbyNo6rUpvDgHCYPMEH4K3aTN6mNbnbE+x6EiFrEOCEgSqIFVyaUpTSgBCUwuSuUL0hiucmFyYSkSsBlaqGguKxqmKJMlTcSqyY2ColVSdk0h2Kql1NzRqQY7xZeV4mzyHaT/AAdCvTnH2XI+JeDMfUzMe1pOoMxPSAoSVo0aebjI5p1jY27pzcVsR+/wpK3BnNEMeCQJgWHS6zhhaomW3nUXIPUarO0jp3JvguHFAyG6iAOav0q2jjqbcp9+S54kE5iYcNe37rSZV0vI2IVc0izDabZtU/SA467/AM5JwxhzQD3OwHRUauKDsrdgLfe/80VrCCO23Oeqparlmvdu+U0C7MIgwRc632ssjiPCA456YyuvIt9Yur9CpeJ99E4sN556iP4VFTaJrHaOfwtct9LpBGq0aFcOvvuE3jHDvMEsMOBsYseh5Ln8Niix5Y8ZXN15FWKO9WiLyenJKXXudiK34RymeXRaXCAM/wCEuGthJA3sbO7LncNiGuAc03GoW94axDfMNNzw3NYP/wBr4MA/8Ta6q28mmc16bovPou1bLAebWBsm4EjRUsVTdckXnYWPaLfC2hVLy2mA0ANh5B9Dst3H0/rCyOI4oMoEE/mhmxvp9L/Ki1yZZ04PcZONxBDZaYPUwPdbPAsMD/rERIgRpA1LeUlYtPDHE2c30zcixd0B++y6n/KAaQzH0gABrHQ0AaARc2soZpxiq8nnM3zSsq4/ibn/AOlQb09P6A7BU6fBcxzVTrsPuV0WHoUmN9NjyAgDp1U9PI8gEWbJjTbn8rL68Y8Io2PyU8Dw1rQYEABaWEDgJdbl/YJHYgEtYLC31V0MkRvt2U7voRGMQAc88r9l0eAxBe3M6Lm1iJHYrjqhyvg6bzotzh1V7ntES0RA1gQb39lfotT6eSvfx+oPk30ISL0xWOCVDUKIyo5NKc5McUAMcoXlSuKgqFJjGJlZ0BOlUMdVvHJVyfA0itXCrFqnc9RwqyZyfi3H1Gk0QyGQ05834gZlpbGgideS5OrjHPMlxJU3Ehlc5gJdEiSZ32J2mVUZSI0GupCpcuzqYsNJE1LHRZxvt+yuHHNqC4BMX5RzB2VTMbDlsn4ZhLszW62O3uqpNdmyMZXSFx3DWOAIBk8jcdj+8qi7hdVjZbJbyMZh8Lt8HwJsgucZi4Hex5BaNTh7CQ0gzYAN37wsr1KXBd6KfL4Z5Vi3mIdLfor3DuIkNvJ5f3XecW4RTynPSabWaBdx2n91hY/wYIzYZ0PaASx19bxOyms+OSp8FfpSjLenZFh8RPJadDEDJ6wXAQA2f90xFjvBXJ1qjqDwKrS3WRt8rawFYvPpcA0xBtAMamfe6jKHk0wyprb5LL50LbAacwsfi3CxVHp9LwLH7FdqzF02U2ODQ5wzDM6YcPTAAjQgEXiNVLj8HSrUP6imzyiLAXyuED8MgAnXTrZONx5TFKcZLbOPD4PIsPin0XEPB3C6LAYprw3KTmF9dR++qt1uHMquJI7nSVEzgIE+U7K7abieoUp5YS74ZHFgy4+FyvxN7CYhwYfKcQXa3Nxyc0a6rO4jFU02vdZhLiRYOcRA7QCdFyn+YYlpLXSMpIIaBrv1V7h/FmkgVHPafj9Qk8Uo/N+Ri12sco7YxavttHV4ZznQGhzWCzS1sN1iF0FCo7KGkyCVVwnGmvY1oazJBAaLfB5q3hazHOh1rQJjRcvLNt8o4ymi5Tws3OlroFINz5nwCC0e+87KH+tFOmW2Ak6dZ/eVRr4jMzW23Mqra2LcvBpcNc0UyMxcYG0b6BXMViS0B9hoD+iyOG14cMoVji9F72NDTN5cBMxyjl17KttqXYn9nouDLUIJnTWbHoFew9R3mMDTlkgTy5GFTwnDXuY2GG0AAcuZ5LapcNcDTdlIdJDv+o3P1WrDgyzkpbX7/iQ3G4kSoXsCAoQgJVECo5RlSuCjcEDIHqu8qxUVZ5UWMSVlYh0uJWmSsrFCDKrkSiZfFuKNotvdx0H3XN47jr3XbI0tcfTZVvEdYnEuJNtB2CyqtbfkseSb3UdrT6aHp7n2NbWzudOoN9j3HNT+XP4TaJnosfFMk52ggg7awrYxdIvLXOE2gkWvrdQkrLoS28E5owTJvt1WjwaiHVhJAHK9zuR1VSnRBNrtHVXuHu8uoHRb+adVTO6ZoxtbjsSxr2EEGTtpppPMK3hXCxOsbc91BhnBwHK0zuIlWmNAcIGv80XMthkfgrVA90zlsdbiR+6ZTohuoAPPvcq/N8oaYMydhCr1aesnrc730TfIoz8eDM41gadWk4ObmsYtfuvPH4X+mrFjCSLEtO4OmU78udivWWCG6arG4twunUbVabZwCY1adZHxorsGbYtr6CovlLlGNwurTqubTGWHRLtCC4fY/quk/wAta+k5wIbkzB1PNoWwC5vKwJXn2CYadTI5xBkjkSQdZXXNr3ccwIcJLnSHSZnSx/uFpltiW1KVNOilxBjc0tECAPm4v9PZX8FwzNSdVLhLC5sHoAT7kLKfjAXtaRLRrax7rOxHiIMDqDHz6j6dmnS7vYKMFfiyU8sYKt1f1MHxI4sxbshFw0kdSNvaFDhsY0kBwg8nAfdadB4qOLa4BcefXdp2SY7w+5oL6X+ozdv5h7fmHZaFONKMuzPKWoxN5MdSj7exPhskemWf9Db/ANTZXsLXqC4eHdxlPuuXwzB+V7m9NR8FaDTViRDxbSx+D+6hPEmUvUfDtT/qx2y+n5HY0MaHf/s2DsdR8pmLpkRDwQdI1HssLDcViz2vb3aY+VpU6geQWxO3LsscsDi7X0K83weEoOenyX937lzA4zI7IbkxB0y3XZ4Co4kz0NtNNAuXwXDXucXANGs7m20Lp8DQIa3l0WDPTfBxYxnF1I63C/gGnspVXwJGWAZjqrK9hpZbsMX9xU1yCEIWgQoSoCEgKzgmOClKYQnQytVCp1FfqhUqgUGMhKg4hh7Sp3K+aOemD0VbGmeSeLcGQ7zBO/xuf5zXPAWk8p+i9P4/w6xtIXnXE8A5hkXb+iyZYOzr6POtu1lTJJEDv2VXE4MGTyV2mSI2T3GTOo/mqotpnSjCMlZz9GrVon0abtOntyW7hONscPVY8imYzLHf6LMxHDcwFxb6KfElyUSi8b+U77gvFtGE2Oh1+vJdRS23/VeJUMTVpGGOJHIrtOAeN22ZiAW7Ztvc8ljz6V/aiTjmU1T4Z3za8WP91EQXGdIMge0XUfmzBFweXKNUtGtcm9ot05rBZPZXKLAZYc9VTxT9ZsIue2pKjGJqecbgMAFjv2O6xvG2NAwtbLEjKLGCAXDl+ithDdJIHcE5P2s83xmIPnucyo4guMTqATaF1vDaZe0NfWd6hYQ3tqO24XP+DfDtXH4kMpAZW+p7zo0bE8z0C9z4NwDC4ZuRlNp8uAaha0vLz+YuIsd42sunqaSSOG8+Xc9sjm+F+Ao9eLc7ygAcgecz3bBxbBA6DVdIPC2CfS8qpgKLRBDS1rQ4A7hw9TT1laP9IyQXFx3zkmNdCCdeyuTmu2+1zoOgWP1pXx9CMm5duzxzx14Jfh2tq0C5zWn0uMZh/wAXxY91kcF4mbB1juF7rjsH5tN9F+j2lvODsfYwvIPE3gvEUHF7AAAJDxJaSNuh7q5fPGn/AAdHSaiV3fPt7/uUuNcAFQGth4bUN8v5H9+R6rmhiX0zkrU3NIMn+brp+D8TcfTVGUixB/UHcLRxeFZUaQ9oI2O/sUo5XD5Z8m3UfDMepW+HEjnMFxUFwiTcWiV21HhdOoHV8pp/hDXAkAkAXyRHSei5rB8FArDKY3aRck6xH3XdcHrvc2KggCwkFpJjWCsesyVTgcF4c2lm07TJjTFNobSBAc3MS7UTIAH83Whgm5WtDngOOsc9rqhVqZy0AxlkAEEa9PYLoeAYEZC4ixPp6dQqNNp555bUUbi9w+jlbO5/mitplGkGiJJ7qRes02L08UY0Vt2xEIQryI4IQEJAQFNKeU0qQyKoFSqtV9wVaq1QkgKLwtDhT5aW8lSqNS4SrleDsbFVtEkXMfgg4aLhuO8FNyB3C9H1VLGYMOGijKNkoTcXZ4bxLAuafT+HlpHRUGPLZBXqXGOBSSQP2K43i/BzFgRH0WacDq4NV9Tm61EP0MKwKYjKVQrMewwR7hPpYog+o7KqUJUbVmi2aLcM0tMgdxqqOL4cAQWEWuO4T6eIMEj27qSlXNs39lXUkSuMuB2HxuKpuDm1nHfKYLTv/IW1R8R18pDmdSW69ohUsPUk9LX1+ivYLDB1UMdOQ3JFjESY9gqZKMnyjVGCUXIceI1KzXPvMenaJB0XAVMIXVDnc6xggkuOptJ6kr1zi1FtGj5VJjiPSS8iHG77k8tB2jmvP/C+EGJ4gKb5yOeM3RoJ+wN1pwr02zkayanBNHoX+F/ht1Ki7FB+QvY5rR+UMm73Dd1rdl2nBKWSm5rXl8kn1CDmcBGhtoCpv6ZuTyQMtOGixib/AIe37wpqeHFEBrNXG0311ce0gLHllKc93hd/+nPVVQ2szK5uYF7z7NaFeBH4YHxAnomU220+U+k6Top4opS/7/vsjJ2itiapFRrACBlLyYtrAEpPEVZrcLWc8gAU3kk6CGlWq1DPqfTbSxsefsFxf+LMnC06ZzZXP9RH4TDZAdzM3HY8loUNm5+GR31T9jgj5dZoI9iNUtKs9pyOBcB+YfcLEwOFfTBNN8mT6ToWgD6yVu8MxYeJAg6OB1ndZpQS66PZaHX4tTHj7XsX6NVpgjuI2WjgXPbWd5ry7KzM1p1Dj0/6zbmViU+Bl1Yvp1HtDgSWtdl9USD0ndbeD4MWOD21CXXkuufncrPkx71S5OR8X1G7/K28+/6Gwxhe9rhoQCPldthaORjW8h9Vh+H8ESc77wBftouiXY0Gn9KFvs89IRCELokREqRCAHBKkCEgISmlOKRSGNKhqNVghMcEqEUajFWqNWhUYq1Rig0MtcPryMp1CuLEaS0yFq0KwcJChVEgq0QdVlY3g7XbLZlNKTQJtHnXF/BrXSQuQ4n4WqM/LI58l7g+mCqlbAtOyjs9i5Z5XyeBjCltspHPqAm16JY6wkbdl7Ti/D1J+tNvxCycZ4PpuFgRy3UHiNENW07PL8HWyulzbb9RyV/C8UIc0tkQZkGCNrELo8b4LePwvHvKyD4dNGTqTrqVnlg8nQhr49XwanF+Ph9EsAgayTBO+u5sB7KD/CzAtbUqYmrYAx2lwH3+qx62CJN/jZdz4DwAOFrNP+76QCqcyksbfkxajNCTqHR2NRk1abi6wzucOZEAT0F/cqw4l81BIi0DUjl01v8A2UJYOcj1OJ6F4JH0Uz4LG0/mN+qwJ8O/5fgoXgkZQDwHE6SAOu902q3KXHNFrToO/wAK7EAALJ4zUaAZ1MwB8LTmxLHFV9rj8iEZW/uK/FcZUpsbXoOEGz22c2dnN/nJcR4+8SOOHYyoQA57bASXEak8rLWxwksaAcrBl73mSOdz8rJxuDpVKebEs8xpqinlFgLTnBmQQs0s8lkSd17Fc+ODkjRaQ2ownsFcq4BzAzEBrwX6+n0nkbLU4hwYFjfIptblJkSRa2WxJ+V1mHxWfDNpVW+oBoJtFldHJ6lbQ0+SWOe6Lproo8J8vyA3K7zSZMiIb3W1hMMXEABR4HDAWaF0uAwmQSdf0W7TaZrsvz6mWR3Lsmw9EMaGj37qRBSLppUYwQhIpCBCEIAcEqQJVEZAhCFMASEJySECI3NUL6atQmlqKGZ76aZTcWmQrz6ahdTUXELLFOqHCQnEqkAQZCsMqzrqoOLQx5KRBTSVEBHJjglJTS5IZBVogrFx3DZm0rfKYQk1YJnC4rhkbLd8DMDXVWncNMfM/Za1bCtdqFTo8OLKgew6fKzZIccE1I1KdAtDWzMMInnEj7/RJgqhLm5tjH891K9x/LzmO+v6lNDfVP8AP5qub6Ek00i1TVUaWIqRHNZGIw2Yk81oPqy0cwoHLdNb3bK1wZNXBLNrYKxYGgA6iBre/e66JwULmKmeljNpsTZiVMITE2A2G/KeamweAJNgtmhgC46WWrh8M1gsL81q0+mUFSRBkGAwApiTr+iuFCRbkqIsEiEKQgSIQmAIQhADghDUqiMgQhCmAqEITECEJUgEITCxSJUAVnU0w01bhJlTsCsJCUtlTliTIouCfQ7KrmlRkq9kTTSCrcGOyiU0q6cMmHCFQaYyonNU/wDSFAwhUWmAzMml6nGEKe3BFQ9NsdlZpSlXWYMblTNpNGgUliDcZ9PDOOyt0sGB+K6sShWRxpEWwSFCFYIRCEIAEiVImIEiVCYCIQhAx4QkCVRAhhEIQpAEJYSITsBYSwhCVgLCMqEJWAZUZUIRYBCMqEIsAypcqEIsAhLCEJWAoCIQhFgLCIQhKwCEQhCYBCISIRYBCIQhKwCEkIQmAIhCEWAQkhKhFjEhEJUIsBQEIQkB/9k=',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'ไส้อั่ว เป็นอาหารพื้นเมืองที่มีชื่อเสียงของภาคเหนือของไทย มีลักษณะคล้ายไส้กรอก แต่ปรุงด้วยสมุนไพรและเครื่องเทศพื้นบ้านที่เข้มข้น รสชาติหอมกลิ่นสมุนไพรและมีรสเผ็ดกลมกล่อม นิยมรับประทานคู่กับข้าวเหนียว น้ำพริกหนุ่ม หรือผักสด',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}