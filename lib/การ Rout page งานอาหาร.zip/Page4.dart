import 'package:flutter/material.dart';

class Page4 extends StatefulWidget {
  Page4({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page4State createState() => _Page4State();
}

class _Page4State extends State<Page4> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFRUXFxgYGBcYGRgdGRsaFxcXFhcZFxcYHiggGBolHRUVITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0mICYvLS0tLS0tLS0tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAAMEBgcCAQj/xABBEAABAgQEAwUFBwMDAwUBAAABAhEAAwQhBRIxQQZRYRMicYGRMqGx0fAHFCNCUsHhFTNyYoKSJEPxJVNUosIW/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAMEAgEF/8QAKBEAAwACAgICAgEEAwAAAAAAAAECAxESIQQxQVETImEUQnGRMoGh/9oADAMBAAIRAxEAPwAfJlzkh87MPZGgiXQYurIkkZiXeBqpk1a+zBZG5Tf3xIpnlpUhIdSbh+UbOK6XosEitQo5XvvEkpip01EohUwKIUbg/wAR1TVs4JK5i+YCQNxHNDln+yzER5A3CMVVNS6ksB74nYdWSpysoUwBYmMvpbZROSWdtHJibWUKka6bKGkRMsZmlS2hg2RHCkw6Y5IjQDQMICPVCODAB6THOaOlJjmADlZjiOliPGgA8yQ0qH8sTplD3QCITlzTj1sxd8QQYUPrlNZobyw1PaNjKo8h0pvHhlx0DiOFw5lMeGXABw0JocyQiiA1yOHjwiOwiPSINhyGxHpEdBMdZbQBsaTCUIcMuPOzgO7RGmCG1oiUqXDK0QA0RWhQ5khQGBxFSpJCEZWJa1yInUHYJm/iKKlE358vKPZ8+VLPdv4Bx66QMrahZnS1JRkDam4vuY1S2tHlos+NcOT3CpKguQRoLKHiN/KAFTmkBKHBzEi+zxbcCxYy2SpQINgYN1eDU9Q68iQsj2wNfEb+MQz5VY64Zv8AY54+S5SZtMUJUsgTO9sB16R5RzxJlZiggqNzzJgnWYZNpZ0wrlDIfYVsbbK/YxK4clU1akonpKVEugpU38PFdZJU8vgWk96DHDeNFaQiaB56EfOJ9bgYX3pJA5pP7GBFZwnUSQVS1dsgXGUNM8xoryghhGKGyVgpUNjYx5WTeF/kxP8AV/H0WY630/YEqvw15F91WwO/hzhyRJK1BIYE89IuVRJlT05ZqQrlzHUHYxVsb4WnIKF0yisJN0qVf+Yqw+ZORa9M66qfaJFTw5OAdLLHQ/sYFT6dSSy0lJ6hosXDPEImPLWGmILKTy8Is5CVpZQCh4fEbRmfKcvjR3mZkRHJEXPEOFUKvKVlPI3HrtFbqsJnS1MqWfEXHrFUZZr0aVJg0xzDGLTlSiAUkE38BziBKxRQssDVrRz8sp6MVmma0w/h0l1Pyg9KoHBJLEbfOAXD2JSgoZlZSf1aWi4ImJZ0jMDvzjzsz522xF0qe0VLGJOW7G1jA4QT4m9lZLhi/wAoiSqKYoOA9tiIf4eTppv0PwttMjmOpUlStA8dpo1lWVr2cQbk0TJyJBJIuR8IZn8jX6z7C8mukVzIXIIYj6tHikxOx+QUZVDRgD5RABjXjZHc9hivkuzwiFHq0xyIpGiBhEwo8eABKMe5o5Ko9gASTHsIx60AHhENKTDpjkiA6mR2hR2fOPI70a6IlBiiELMpaSEuw3I5A84J1s9KklKXvZ8sC6LDSnOVylqJIKWI5vrDs4TgoGc+UuUpCmbLqC3jHapSts8cepKyUkhEuWpSv3FncxZ8CxhSSEzGB5AvaKnhclKzmmqAuyUBTMOR5w/jMyWjIJJSF5gLG+vSEeRgnNP8/A3HfFmqJWiagoWkLSoXBuCOkVDFOD/u5M+mzKQCFBAcrT/j+oe+HMFxUgBK/X9x8otlJV9bn0V1B2MeVGS8FcX/ANooqFS2D+HMeE1F3ChYpOvjBiqpZc0d8eBGo+cAMV4dHaGrpnTNA7yAbTGGjGwVppDmCY4mcLOlQLKQbFKhqCNj7jGb1Pc+n/4bSbWwh/TVouhWce/z5x3T1WxcEajcfMRKk1I1f668vGHZklMz2gx2I19d4U8a9yHJ/IJxDCUTXWghE3ZaRq2mbmIj0lcuWrJOGVeyhorqOY6awZNIpN0393u5w1USkzElCw/T8w+ucdrk1qjqa+ByVWDf/kND4xK7QEXAY+YiqTjNptyuXza48W18YmUeJpUHSrL46GMLM56Z1x8oY4i4JlVPflrMtf8AyQfEajyjPce4Rq6fvqQZibuqXcdLaj0jWkVf6u6eY9kxLRUHcOOaflFM518k94eXZ8/GeSQb6DNbcW1EXbg3Hgfwlq7w0c36Dyi54rwzR1b5kZFkNmR3VbajQ6biM8xzgKqpfxJH46El3TaYPFO/iIbub7TEOKhh/idQyLdvZfaKBhFdMzAJWQCW1g8uvE6Qouc+TvAi4ULEQE4dklDKUkEg2f4wqF2ynFl4bf8ABoElIlSyo95Z9Xh/h2qyoWmYohyT1AOjcmiozsUWq7/P028YlUGJqlKQSbkXe+7X5xl+idX+xYeLEBUklwoMDmDX62iq4NWSFpCV5kKFn1Bbcwd4rrx2NmZvAabchGc4WoqudfrfeH46cptFniJPJpmgnCsweWtK+jsYhT6NaPaSR5W9YG0qlAWJEFqXG5qLK7w5G8NjzH/cX14/0QwDHpTBhE6nnajs1dNPSGqnDFpDjvp5p/cbRVGebEVjaBTbR0EQ6YQ0hxgbUiEQY7Mcq0gA4jnLDoEIGABnKYUOGFAB4MblKYJzqUdU5dGtcwLxmdPSoKWPwgpwWunZlfxyjhE4zJsspyy1kKYJcqUANwzAWiZSvMCkz1hY0yg26uBoY5fGv12eS9emMiklzUW8XSwI3vziOrDFJAynOkKzMzK9T4aQArpMymWci3lvZQuA+gWPyn4w7I4lnjVlDnCFdScSaRbVLmJldrmZjYFLHwHXrBvhziBM1Nv9ydweaffbS0UiVxShQyzJfi1x6GJ2GyqbNnkqZe7KUPVBN4mzw8j2ynHniZ009mtUdY7czodldD1iJi+DJnHtZR7OeAz7KGyZg/MNL6hrRWqDGMllg5Tr06htPARYJWMyxkzLdKiyFjnqyohqaj36HxkmvTIcjFFoX2c0GXMHvHNJ/OPfB2nrw12Y7i6fMbGOaujROQ0wBSdlD4gi6TACfQTqZygmbLJ6Zh47K+PjGGnPoZ0y4yqizv8AunyO0SCUq1Hn/MUyhxhLOHTzbT0OhgxTYgnmU9dR58o3OZMy4Cs+hcWYvzisYjw+tKs0p0k7apJ8IsdPPe7hhcqBt5iK9j3FDOiWWGjw+fHnKtvpGHkcHVIlctLzpiZf+j2z6DT1hTeIpKC6EknxYegilVeJFRuXiEqeSHAJHMB4dOHDjXr/AGLd3Zdp3F5JslI8n+McJ4zXz9wioU1OuYWCFdSbAeMS8SNPT2JzKtZTg3tzZ7e+NfnifSBY6YbmY/LWSVSJKirUlCXPiWvHCqigWQlVOlJIcZCpJszsAWs49YEIRLUgLCCCS+Xpy8Yaq5A/CUEqQ73U42Zn9PSOPyJfwH4HsKzeGaKb/bnLlq27QBX/ANksfV4GYnw9WSRmEsT5YHtyjmIbcp9p/Iw6lHJYfxB+BidQYhOlXB80m0a1itdCnjcso2JYqTISgKvd325iCXDfDFVMldqiSooG5YP/AIg3MaLh1ZSTpgmT6eUZu0woS/n16xYKzFOxYkd0+yRoYxklRP8ABT41OX17M2kYZMQoJmIUgnYhokTaCLZVcQSlqSCAoEe/9obVPkTTkSE21UCBttzibnjXWz0Vkv20UtdI0O0lfMlGxLcotNVgCsuZLEe+K/U0bbXjTnXaHTkmiSlUmoGyF89j4iB1XSrlllDwI0PhDC5RTcQUw/EwR2c0Zh1h2LyXPVGMmHfaBRMeiJ+J4bk76e8g6Hl0MQEx6M0qW0SNNHRjnyjrLCUmNHDgkQo9yR7ABAnYlkmZCGWHBO7EuB0sBETFcKTPImyV9nN6OyupbfrEydhkpSQlZWV377jMHvltYgF+cD5tHNp2JOaXupL+iht8I8jJkTyupfZ49PsByq/MTKqAM4cFxr0PziPV4KA5QrJuxLpgpxHhiahImyh+KkX/ANQ5P+rlACgxnRC/Z2PKLcdq52d18yRpwUg/iJb/AFDQ+e0SkIOqS/UawTnSAzoU6T5p+rQLm0LF0HszyuUfNMaemc5JhSg4gnosT2g5L5dFa/GD9BxJLJAU8s9bpilffCnuzkN129YcQQbpNut/fC6j7Bya/hONqTdKgpPQ2ix0mLyl2JyKOx9k/XSMFp56kF0qKfA/Xviy4fxIWZbEc9D8j7oneCfjo3PkUvZqWIYNLX3h3FbKTp59OhgLUU0+S5bMnXMnT/cn94gYVjpH9tahzG3obQTTxUgKyzGfcpFvNOnpE2TCkyrH5Gyfj9UZFNLlhgpaQtbcyBby0ihzZpUWHnFw+0IOuWt7FAIPxgFh1ClW60p6DU+UW5KUalGZnk9sHowsK/uLyg7OB/LQTpZYCiGy8msWsNNA/wDMMygiWpV2Id+lnBIP1aIS8ZR+GsELEwMcoNms3joYnu6pb0PU6LBNmLTlCEpSxfY+G94hV9KJs0zpxC1NbQJF9AkH4vpEaTWyyCUEgpDkHX3i9yPWIfEMyaJEvJMJKiCRluAeuwvCVy30b6CVHNW680tki6Sk2y8ywsRb1jqtAXe7ENty1Z+kB8DxBaErUSVuggpZ1MO8WHJgfSJsyomBBUUDKWYE96/MNY+MM/yZ19DNNRpll1KAB/nYmz3tBhE1QbuhQOig72tcNrpvAZUlM1aEJWSCpz5d4ufG0ETVJAUC/cdmAcEfq3IsYE9PaZ1r7JiEBWjhXIwcwisC0mnnOUKDHmOo5GKhST1KOZlP+p9yXNjFiQHCV7uAf2+vCKsdt+ye549ork2RUyK1NItIUHVkUPzpLZHGgLG/gYs9NgKR3hMyv7WVNhzAc8xygzjciX+DPWjMtCAzajW7bkAn1gDIxlKJishSQQ+Ul7v8Yh8iFGTWuj0sWSrhMthqmGUBy2o6NAerw5Si9n5fvBCkmd3P0zHoNfSCDJWlwL7EM8Mhul0K3+N9FGr8PUgsoN12PnA1FCtawlAdRP0/IRealw0ssoEE97Z9/COqHDkoFjqb2N+g6QOeQ9eQ0u/YJocOWkZFLQsGxS59xIYwDxjDDJV/pPsn9o0CYUiwYb6+sQ8Qp0zZeRbPsRcgnQ2irFf43pk9ZHXbM8jwxMxCgVJICmIOhB1+URIvTTW0A3ePY9KesKOgBJ5mS3WkibLGqk/l5g/OJmGYuFWceDfF4IjB09jVTEJAOUI7oAdyToCWLc9dd4zCiE9C5mVKlIRdTA2vHn5fEmXuOjymutmkLopJLo7l9B7J/wBvyaKvxLwulZzygETNSNEL8D+VXx98d4TjYO/T65RZaaoQtLKvytbyJP7RPNVDFptMy2mrZtOsoUCwLKQrbfTbxiw0U+VPHdUAr9J/bnFkx3hlNSASWI9mYBcDkoPcRnmM4RNpVsoW/Kseyrz2PQxXNq/4ZvSosdRQggpUA28A52CkEmSpj+k6eUd0PEKgyVjMneCktSJt0G/J7iGptezPclc+/LlnLMS31tzgnS1qVsAQP55RPqKdxlWlx1EB6jAg+aUSk8tY41L/AIOblhmZiIQAElidf2j2XVKmEDeKzPkzk3Ukltx05xzTYyUXYu8JeDfa7G666N7wWoFdRplW+8SfYf8AM2qfOBdG5zDtFS1JJzJDpWC9wwPWKLwpxCsETAWW5dvF/hGpUWL09YPxWlzSACsfmbTON/GNXCr37HRWivYrTSspdWZbup9xYFxYkXdtjESiVLTJ7OXol1XAJtyOtoP4/wAOqzGalBytZSDmTs7+m8VhVcJeZCEZVAB0trsQPcREtq10yidMkqGRpkxsrgjQWJcgn0huto1TUJUlYuGtful1Bjv/ABAfLMmIJLMFMQTccu7uOoiRhuIdnmE1RNu7y8oU+S7aGaX2G8CmpkzHKbZWzdSzjo7H0gbxPXfirloLIJSoncOHaBtXixXLN2u5V46fvAWUVTFMCTzUTqNGeNRDp7Zl1xQYlkhYKJoDfmGvPSCtbVSuy7hJmKJKhZupPrELD+He4qYFWTcocOUtqCbRHkU6u1HZm1rKb3h47rfUndr2WvBahXZpQQCLG+9oPYVNK5vYpSeZJ0DEF/DWBeDYFOKSQ0sG5mKskPrl/Ueg90EK/F5dJKMuSSon2pivaV4ch0h65Jr4Qmu+grX1hXUBEtSWQliCdRvtAer4WSuqRNTnRlUhSkhspANw45h94q3DeMZ5q1KUCQoEHZiBbwtF5RiiNCQemZiH0vpzt4RJlvdtssxpzOkT8oUr+2kp2UCdwzFjz2gfOqahBIl2TmABJ638dDDk+cLstIfYu3XvfvEfB6AqqCuYHQkOltHYAeO5eE620hi0k2yxy5LtnKpjh81w/J+Q1tEw0+ikNfUE/DrDiamWU5Ul/wDTzgNPp5gmDI6ARd/5i6tT17JFun9DuNUczKFouR+XR+fnA6WVAFSnSeXxLQqqatNjOzF9gR+8Mq/EzvLcgBLjW53v1jjSbGd60wTj9UFFBHsvkSTZzzPQkQNMss+3PY+B3gpX8P8AayFSyvKVWB1ZQLj4e+KhWyaiUP7yyZRL9oAAWBslBBJsWdmaL/G/4aEZMnB/wGvOPIq6sTnG8uYkJ2Cg5GxuH3feFFGg/qI+mXvhuVLk4dPUFGYnO5U6TmdKQC6bMzfVor8jEZSBlSkJBJJbcnc8zFv4DpZRk1FOAkhXeIdJ1dLkJsl8nsjSM04ow2ZRzVWKpL2I1T0PMRF5WOqrp9fRDSbXQsa4ZEz8amISrUpFn8NoDYfi65S8k8ENbz68oOYTiztlL9XglXYUiqT3hdvaDP8AXQxGq/ttGN/Z1hmOJLEFydr7fGJ9RNlT0lExAL2Ol35jnFAq8GqKQlSO8jpy8NRBjB+IkLYGx9DHKhz3L2g7+Afj/BK0kqp+8n9BN/8AaTr4G8VabLmST30rlqB0UCPQ7xsNLWIIsQRy/jnEmbSJUGsRyUHhseS0tNbNcjLaDiNQDTGUOuvrBqmny5l0kDpp8YI43wbJmPkAlKZ+4LeaPlFblcNVcskIT2vLs7n/AIm8N/JNLp9meM16CdXWS8hSL33a7Wfwio4tSWzAWi+8J8D1FUc856eQCQVLT31FNilCDd3Gpt4xeqXg2gCVyyhU649pVwDb8gEK/KsVbZTGC69ej59w2t7NQO28XjDq4KZSFEE/TRr9Bwrh0ogIopIIFlZEqI6upy8BOOeEpXZrqJaMikp/7eVKVNuoBPtAPy8YbWeb7SG/haAOGcWzpJbMf29IMDHqSeoKn06Cv9ae6rzbXzEZoaop1090SJVYLNr0ju+gS7NAOC0MxWZE9csnZSUkeFmiPU8EoUkhFTIOhBVmSeosDaA9BhFYsBSJSyFXBYD46RLn0NZKRnXLISNdCQOZALtCm5Yzi0iT/wDwWpz07k/+4sj0yx7Q8CiXddTJT/ipR/8AzAUYsTv8Y9ViKv1CNppfBhot0vDaSWGVUKX0SG95JhkYhRyLyadOb9cw5j4h7DyEVI1hP5rRFVVgDbxOsHW/QaLHifFEyafafxsB4CBNBSrrp33dK8oN5i90o07o5nbzO0V+fWEqyDU7fueQi+fZXhd1uoklTqUQLABmH7eMcb+TUouGG8G4bTJyJkObElSllRYM9y3kLQRTR06G7KSkEM3dct0Or9YIT5SJaTl13OpaI83EMyWBUHsDCcj7/Y3O32hqplpm5krlILBiFJ56f+YDU9MJC1y3ICy6XIdgAGfcO+t7w8jEF94TC5zXte2gePJtMahPaI5gM7MA+Zn3id1t9ex8rS79EmXRFTFKvMc+Rh9S1ptMforl5wEmzFIOUHJlHsm9v3gXOxVa1XUdbagRtZFrWuzjjfyGcSrQE91wRzvpuCYjS8QUlI0OcM4e3jAGVV5pihM0Gzvbn/EOV+NSyMkoNoygL+nhG1Tb2d4a6ClLUETL3A3GrfTQJ4pmiasEuhRBB7MDMUl2BWfZFzEfMrK5UdHe3hceUA62rVmUrtCQLLEwkSiADYAXKifK+8U+JLd7J/J1x0R/6KP/AJCE8hkdhsHAYmFEKbxBOJ7ploTZksLBrbH4wo9MgLzwFVGRUArUFqmMFqGY8yBb8NKRYBufIiLdxPhaVKIIBSoRjMwzpSkS5M/tFBXcli+XK+XMpfcFleyPZBuBttnD9eKylCVZRNSLsQQ41uNYxS2aRkPEPB8yQozKcltSnaBuG8QqQcszuqHpG0mQC6VC4tFP4o4JRNBUkMqJsmKb9nHKYOlYqldljzgLjvCyZn4kgsf0i3oecDainqKQstJWgacx84KYVjKVAMehGhB6iIai8T2jDlyVmTiVRTqKVPbnr8o2LgDCFVMkT54WiWQMg0KuatHb4xA4fwmRVTkGYgLCGUQeY0fn/EadTz0kZE7WjX6WuWux2PHyWwFX4LTJUkurLuH1frEdOISqdCglAQST3hv4nU2ESsWoFzVJQlaEp3a5AHTq8V7ibAFJSlSl5pYNwAxvYEl7iJMlUt66PSxYcS19kDEuMCtWUOvonR+sMUZnSnnKXkzXIgfV4vJpO7KQkrOqtWHLxgPifEKli5ccoXON0XLUr0angvEcmqlA2JS4VdiCNz4xNViA7N8mTQOS8Ybw5VL++S0oUUdoWVyIbMXHlGvYcFTkg5z2f6so2tYbDrFN7x9EVROzJ+LfwqiaggZVKzpJZmU5LNoHceW0XjhmlpJcqXMQkZigKzFipyBoTpvYRcsKw2UlS+4lWYAFZSCSP0ktp0h+Tw7TpJKJEtIZgABl8k6D0jmWnkhKTkuYrsj4XWhSHURdwDzAiSJoOpBHOBk9KyooyoQENYMB0ysIh1depJCcrudRz/aJJpr2Ocb9AHijgwLK5lOsJWHUUXZW/dI0MZ0Klj8/lGyTKkDvE3b3xkuI8LVM6tnSqeX3c2ZypkjOMzP4vbwi/wAbJybl/BPlxpdkKdXk2doHzsUylkkn1cxdcH+ymetX/UzAB+mUXPmtQYeQMS5v2Ry0B+2mPqHym/Jmc+6KeeKfbFKW/QKwHA0qlKnLUU/qIDm12jRvs6oxKplur21O/R8of0MVs4PNkU5lhl951MC4cjUcos+FTTTDLMS6Qh1h9Dc2blEzy8mN4aRaqWUZaXYzUtrYHfQaH+Iif1KWRZOUk6K0HW0DqTixKVlBClI2PLpDVbW088lIGQjnYHwPOB1PHo4orl2DuIsT7NWdTAe4naOcKxoB0hWz2/Ufhr7orXGWKZZfYgImKcEPqL6t0AMV3B5swTBc97mWA9NukTVhb/dMsxta4s03FZU2ZJHZqSZoezvmA1APOKjIrVKJC1MRqAO84sQx0grhGI9mWVfcM7P5RRuNcUatWtDMoJKhyJF/OwhmCXZmv1egrXqZeYEjMbuzx4Kghw1+fQ+MVn+vt+onq0P4ZInVK8xdKByf4xT+LXbM8t9BrG8XdDJVlGXK/XpAClmBffmKUoJ0AcAszArN9QLRHxqsQZmVIdEtwx0Js+hvc+6GZM0kh7IB0Zh1fKGFn2ePRwxxk8zNW6CgIN82Xp3bcvav6wogzOLJoJEkZJYLJSNh8zqephQ3YvTLfRUEpB/DR3nAJJMwm8shOeyEHc8gHuygSuC4sunmBaS7AOAXcM5sgZJYBsGJfwIiqoxecr/tpmBIGYEKYAKSSoOSEPlF8pYpdtWdRjKJgKC6BYArDgqYpICO7LSAArXR+VgMxo3OVNRVoE2We+1x8fOI656Ug9oQkDUksB6xk/D2NqoVvLUpaSolQKsxN1EkJQlkqLA6+QOukVSKXF6fLnCZguCD+Ycx5wto0D6uuoZ5KAsTOakIWtI/yWlJSnzMVXH+AEt2shQH5gQbcwx5QVra2ow9VPTzB2UlJaZNQkd8PYgkFne++sH6utpKmnqpTp7NCCFqLZe+jNmBG19eYMZaO7Kh9lE+YZk2XNtZgo6ukkKSet9Y0QqMslD6i5HLxjFcHrp1NOBVmVLCkomlu+jZK1g3Dhu9u3ONSmV2cpV7Nhe5dhaI88qX18lODtdBxCyA4ASDvuYHYksLSqVMPdUkueTixEMzsRWQA4Zw3hEaqWlSXVdR3v7xEeVddFMe+zEKmYQohyq511sYclVAS99dQ300W7jHhaQiZJmSSc06YlBQTbMoupaTy1LQeVwJRGWbTCRqvMXfpcQ6s2OUtjd1XoqnAFIFVRmG5QgsCN1WfyAPrG2YTkVlKbkJ+rCM34Y4dlyJhWhSj3C4cmwUNz9Wix4NiAlKWk2c2eJ7zS8i+jjx04b+S2VNcEW+EMLrwRYwKq6/Olgz9IBKxLs1FKyA2h5xyr718GFG117CfENfkyqO5IJfpaAq8UATmF3Z/WION4n2hSE6ddIrtZOMtw/tDb3eEKpOq6Kccrj2Wj7+NSp2vE/hKUVrXOJstYUG1IuASeTAekZ0moVNmop5ZuogEva+sbRguFplSkNcgADkw6+MbnE4MZKT9BaWu4YC27coZrqNSgSlnN25t12h1E8Fm84UvEAk5V6bQ3in0ybbXaK3jNeuSJZMogZ0gra2qWJPrDCqxJnFvZUlz63tuLH1g1xTknoyO6DoOraxT8XqkylgJBSzG5cObX6Qp7h6Hx+07DeI4WJiSpGoYht+rcooON4lOllUsF1J3I6OwEHU8QzSGzMBty8DyiBPwn7w83MyiB4WteGdNnO10ylqqDMmuVOSN+e4+EHpEgKWhIvzI5mJeHcLTFTSCkI0JXqDtbrFjPD6JaQlK7/qdiPGN5HtdBLS9khcpkBIAZgbAO43zRlvGlH/ANWopLhSUq5tqG90W0Vq5WbPMzIv00gUimVWT8yQyQACo6ACNYG57Oud1/AFwHhxU5YGw1PKDXFuJy6WX93k+2RcjYbnxibj2PSqKV2UllTD9OekZlPnrmKKlElSjfmekWYodvlRPnzKFxn2O0srOoJdhuo7cyWiRMHaqEqXdIJuH719b+XoOURkOWQguTqeXQRcuG8HSgBSheLCTFj5Ps8pOGk5EuNoUWZvp4UBZwQIqZ0inPcISS7BKRmsF2Od1hwoXyaKF2LCBivbT+8KXK9jNmvmHNlLPdAchhZmsS0S6qd90WtYzGVMDgoZC82VSmShYKzdVlPZQ1LNA/FMTVOdNPKzOLzBmKrlRYKmBw7tcauBsBs81AzFJ60pSgTu0JDZQ6r5SC5Nie8zXs24t1geLLo1OhSkrZ1BROUtmOiQRo17eHOTJoJcpIMwS0zALkqUo6nRAPJPtDXQBwQRlaFzEskjsklsyglKXASLAcg3g7aa5OmzcNfaHTVaOwqUgk2KVN6jnELiD7PCy5uGz2StJC5Srgg7fTxjKadaW7NTvu2UDkxPjZr6xZeHftCqaVQCiVJHW/kd4y1s6n9k/FUYgkyjMp1JmSgUmdLAX2iLAImD846ERZsMxtQlgqQyrhSCCGI5A3TZosOBfaFSVick3K/oofvDeOcDpqHm0dTlmbJWfc/LyifPjqp6KfHqJrt6A/8AW3OhHjE1OKy2BN+cUnF8IxanJC6ckfrAdLc3BtAabW1ILTcyR0fL57iJP6evllFZI3pFonYp29dKcshGYJ8Skj3xcZdRmSEF302uPGMwplN3uV3EX3AMdROlKKcubQkaHT32ifysThKpGYb5bTCdJhiZSisTCdRkYaHrHM+kL2CQ2j8jCnVLljrzG/SHpVQeTtoIjmW32Pq+ugZlWNXAGh2gPioBBUpVxpFnrpnd1aKLxFkQPac33hyj9tIxN/LIs6vSljmdQeK9jmKKWSnTR4i5lqOpAhfdI9HHimHti6yOukF+AahKatOfkW8bfs8bRXYx2chOR2GrDQPHz3lKFBSdQXEabgHEKKhAu0wDvo3fn4QnypafOf8AARr0y1y8YBSG30hxVapZAN+TwEzAh9G2hLmuxBb4xJLb9mqlB1eZIBJcnltFC4vdYVcgXDvtBybULCSym6bxTOLcSAGQKudRDYTuloJ/VPZCwjHikJQrVwCTcHrFto67Ke8u2wGnnGWLgphBqpndky1TfAE+p09Ysy+Mn2jH5NdM1BWOFKSAwVYDzPOBeLYmEAurMskMlOp5sIYw3h+oCD95WiSk3KRdfyENV2O0dG/ZJCpn6jdR89hCpwvf2DaXfoc/py5oC557GVrk/Mrx5DpArHeMEyk9jTAACzj9+Zis43xLOqCXUQnkD8TAXNFuPBruiXJ5PxI7NnKWoqUSSTcmJUt5dsvfOhvbqB9fPxEsy8qn7+qUsD/yB0ibhsglRWu5PPX1iknmeTCnD2GgMo6++LbTWECKIWEE5S4CyekS88KPEKsPnCgNAWhw9SlpmzZwVM7rJAUtSSDLIBIdiOdwHBAOzeLUQLrWFIWQ3arUy2ZILIQWV7SnSXObUh4ekY/LyJKzMSbfhpAQA2W+bUpGo6EhkxEk00urOdailAVaWhJKjlCAStRJI2GZVgA4jZ5gGPfClTUFUpD95BTLzakKXLBcE5hcaObEkxLSqWA6FIFmSlIK1MMxDE2a1geuY6QWnYaJYR3UpAbL2igT/wBu6UpLBR5guCAXAMV6ukJnr7igVDKVzFd1I2YJDAEu/i4BVrHDqYxiZCbkd5vzKzE9cqbNbXe0DVyphAKwUp20A5eQ/wDEFP6atCnSe2fVUsEM4ctnF1d4HR7HS8RjUoJdxvq69H2Nhs23W0ZOg/KU3ST4jT1g9g3G1VTkMsqSOfzgVVsL6vo5d+oA8Bf+YhKlq1NvH5QAbTgH2vpICZtuYVpFqlYthtXdSEgndMfNKhDkiqWj2VkeBjjSfs6no+jpvA1FNvKWkPzAHvEAa37OKmW/3dm5JIY+UZVQcZVUtu+SOsWjDftWnI9p4xWKaNzlpBaZKrqf+9IUE8wD9CPBxGlgFZk+IglQ/a8khl36FjBiT9odHMDLly1eKREteFL9MoXlfaKNV8RFTplpUp/zGw+cC5dEtZdTmNTRjOFTNZEnyAHwhz/0lV8jeCj841HjcfRyvITM4k4MDtDp4f5RoSqfDCLZk/7z847lIw9Oi1+an+MM/E/kys+jLqrh9XKA03DpkpWdGZKhoRG3LqcNGrn/AHRGnYlhSdZSD/kXjn4X8Gv6lGT0nFE1BHbgqbcMCfHnB9GMCaBkRMWdglCj8BaLavjDDJXsSJIP+KflA+r+1qSgNLAH+KRGH4ct7O/1X8Ak4NiU7uyaVSQR/cmkJ9AS/uhUn2SzSc1XVy0PqEOo+pYe6IGJfa5NVZAPmYq2I8dVc1+/lB5Q3HgmF0LryKo0s8O4TRh1fjKG6y4/46QKxb7SZMsFFOlIbQIDD1jKamsmTC61qV4mGI3+JbMvNQcxfiionqJKsoOw+cBFF48hRtJL0LdN+xRNppSEpzLufyoG/UkaD3w3JlZWUtLpOg/Uze6+sOoBUpz6DQdANhHTkrbHaaVmLn6aDdInTnEOllaQVpkdN+kBVMpII0YgnKH00QJCbRNluN4ByHnEKOWhQGtESmwqVlIRKBDE55h0DqAUEp1AUwvfQsGgfR14pzMkqMxSUqfMCA5GUX/MNLEE2taFCjZ5OwfVY0mZ+FLRkQogKUGzFLh+8WJ08bXJgjS0cpMpKpaQmXrmWVKu4BISB3T3RcX0beFCgOjBpSU57lAYkqLBu6bIT1BIB311ivTZE2oNgnIGAUwFmGwLnoDp0hQo4zR5/TH9guoeASLB9b7u/lESapjlLA8076nePIUZYDa0Wc6ev/iI5hQoAPI8hQoAFHoMKFAA4moUNFGHE10wfnMeQoAHBic39ZhHE5v6zChQAcGvmH85htVQs6qPrChQANkx5ChQAKFChQAKFChQAKHJaRqdPieXSPYUAD0mWTrflBCmk9IUKAohdBSnlQSkSt4UKAcgjKQzRISYUKAd8HJbrHkKFAZ2z//Z',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'น้ำพริกหนุ่ม เป็นน้ำพริกพื้นบ้านของภาคเหนือของไทย มีรสชาติหอมจากพริกย่าง รสเผ็ดอ่อนๆ และมีกลิ่นหอมเฉพาะตัว นิยมรับประทานคู่กับผักสด ผักลวก หรืออาหารพื้นเมือง เช่น ไส้อั่ว แคบหมู และข้าวเหนียว',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}