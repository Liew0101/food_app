import 'package:flutter/material.dart';

class Page6 extends StatefulWidget {
  Page6({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  _Page6State createState() => _Page6State();
}

class _Page6State extends State<Page6> {
  int likeCount = 0;  // To keep track of the number of likes
  int dislikeCount = 0;  // To keep track of the number of dislikes

  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor:Colors.yellow[100],
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0), // Add padding around the content
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center the image
            Center(
              child: Image.network(
                'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUSExIWFhUXFRUYGBUXFxUYFxcZFRUWFhcWGBcYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICUtLS0tListLS0tMC0tLS0tLS0tLS0tLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAEBQMGAAECB//EADsQAAECBAUBBgQEBQQDAQAAAAECEQADBCEFEjFBUWEGEyJxgZEyQlKhFLHR8CNicsHhFVOC8TNDogf/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQMCBAX/xAAsEQACAgICAQMDAwQDAAAAAAAAAQIRAyESMUEEE1EiMmEUkeFCcYGhUsHR/9oADAMBAAIRAxEAPwD0NKUr8S/h2HPWIalCpoyoSEp5jcuWMuUgkp3gGq7Ry5TpbSPG8fUegk70aqMCDApVm5iSdhQCE5CXOpOkLJvalKgWSzcPESu0xVLSlKTY3P8AeI+xgvoryyBc/DyLjxcniNropaQM90njWBZmNZH1uAW2beI6yvlrQ6Fai46mF+mx/Ae5IYVNBJCRcqSdtSIRzssojKHB0P6wDRYmZTZVEs7vEUzFxdhu5EW9uL3QcpLVhVZMmqKZgqO4SnVXI4ymx9YFr+1tOpcsGSFlJZU/IAW3IG/2hFV1pmKIWpkv4eI0rs/PUxTLKwrQpuP8R6OKTSpI5pRTdtlhxrstNrkGbRViZ6B/6SQhSejW/wDoCKKvs/Upm9yqTMEz6Skv5+XWLzhnZpNI0+pqO5ULhEpREzycX9onxzt+pbJkhgLZ1MVkfrFnTX1E02tR2b7MYZNoU95Uz0JQb9yQFk/3HpHcrtBTLqCmUEUyVkvOKRr5DTzMbPZ2lr/FS1qu+yuZU93sLtv7PCOr7IVEqYlCghTh3Sqyf6iQIxPIof2CMOffY3xrsrVj+KlYqZZuFyzmt/S/5PCKRnCgA4UDoAQp/wAwY9EwKnk04AkgggDMorISonV05mUdWDQ0qR3gM1IQlZSQhahctpbiI+/jk/JRwlFCjA59WhLz5ie63E7xFuh19yYFxLHpCVH8PJBUfmaw8hCPEJs0qPfFSlAkX+FxxHCAo7Rt5l0jKx+WFLq1zFBUxRV02HpBktSNg3pAsmWRq0Eoqkjh4hOTZVJLomYDaI1TD9JiaQ80shKlFtBt5xNRUUyZMMsJykalTsOltTE9jF/i+mOkFXQR3UUNQFKBFk6qDkNy8Qok8rfoI0AQAd1RsSh5wJMJBYN6wTST1AMQPaEBMintpGTJAG4EYJquY0b8mARpMsbqiQIQ2hMa7xvljS6s7JMAHYQl/h945XlGrfnGgvke8d96mCh2QGa+gMSd4dLRs30B9Y33e5IEArMSTzHCg17x0CkbkxpM0DYw6CzYmL2AjpTncRxmvZ2jlSE9YKAdVhyIKlTDn6WDRSO0VZKSrOGByuf1aDMbxRV1A2AJ8+RFVxDCzWEzpBUbDMJgypTyytCPeFjx+4ab4bZNJxqWUlXeMSIm/EhQSy2ttvFcxDCZdO3eqKiQ4CQQk+Sjr6Qtn1pIyoZCeBr7xb9OkL3L6LlUYimxMwWDawmn46HISGBOsIZc36rw8wDs6qsKkyCygHZQLeWbQQ1hVg50hhX4igSMqS6jxr5wFh1LNmnLKClk6gf3O0WCn7JU9KM9dPBUL9xKLnyUr/qMre1bJ7uklJp5Yt4fiPUmNrCorZP3W/tCKfszJkDPWzQLf+JBdR8zEtT2oKEd1SSxJl86qPU9YFwDtLLloMqpp01EtSioqNpqSd0r3+3nDpXZmRUpMygnuwcyJtljoDv9/OKLr6Cb7+sBpKuiqEJl1UtcuaA34hBKgo8rGv2PmIirexEwDPIWifKJsqWQ/qmGlD2clSAFVU0A7SkXWekWugyolnu5SZI4J8TfUpvyjM3UbmOPf0ivB6KXh9O7PUTB4hv0SOAPvEkl1IzKlGYVC6lfCH2Dm3nAkpjUvMCnUbE6t5bQyxSrky5glIWVWZTgKSg8Dr0jypSWS5t6WqO1Q46Xb2RTKXulJnDKpCUh0O7EkByPJ4MxCpKVd2lbAhJQ41B0HQiIadYKVTJoVlFlpy5c5B8ISOrAnpCeuBmqVNKx3gUGGljsOAIUpxxrilt+PwCjydvwOEShNRlmgE3A5c8HmKyqnUhRSWcEiHtVJVKSnUqJHXrZvyiEyJWfNMWyndWYFk/8dSYupcVsnxvohwjDRMUQssGsf+4cIweSWyoNrlyGbbzgQVGZSimYsJANyAgM2wOgg7CEkIIMoqa4KsyQoeR3jDm26Q3ClZ3KrGJAk5E3FgA7el4KSofCgsLFmfM/UQDWVXeJACSk7EltSzAGIPw85JUhJX8ug8J5vtaJObv5HxTXwHYlMWBlSBlLvlZ3PIiv2v4T7NFppwACACAgb7qPWBE4SuenP4NwzszHeOiFt6JaXYgShzHS3/lHnDFXZ6a+qQNy7iIajA52YBCUzB9Tt7uYpsLQAVnchukTBKAHKoOm9n56UPnl+Qf2cwuVLmJsQB/xh0K7NpqZZsAo+kaUofTHUmSfq+0SKlH6vtDoAbvAdvtEqD0aOChQ3jnu5hHxQgJHL6PEYmqfQesQ5W1WT5RyqWeCfOAdBqJo6RyqcncwOAdyB5RtKi9m9YBBCVcPGKlH9mOSo7n2jSSOD7wh0V+or0BIfKS1grQ9DFcxzFp84ZSvKgaIR4Uj0GsczqgKsUE+kS4Nh02bMyokqmIe7Fso5zae8WxqS0glXbCsB7WGXL/D1UpNTTs2RYGZP9K9vV/SDpvYakrUKnYZNKVJuqmnuCOiZl3+/mIOldmKOXNCCVT5ivhkJIckByFEa6GF+O9pakA08uV+GSm3dhOVXrHSrS+og3b+gyn7LUVIkLrJ3ezP9mXo/Clf9RHXdsl5e6ppaaeVoAgMSOpgfs92jmU6VSp0qXUSVqdUuYA78pXqD7+kNldlKetCpuHzFpUA6qeaDb+iZofUn0gu/tCv+QiwLtBMppilpCV5wy0zBmSocciLLT4VRYg/cy10s7dIBXIJ8x8P29Yjpex9NTDPWTs6v9pBt5KO8GnGps1pNHIyJ2CBf1MJa1IG0/tBqfsxT0ozVc0KUP8A1yz+ZiQ9oioiTTITLBsAn4j6w0w//wDOZs05qqZlB+UeJXvoPvDmg7P00mdlp0MZaTmWbqKjs54/vGZtxVrQ4pSe9gGE4EZAVUTlBS8vzXyknbr1htS92sk3PiJSSSHCW021iDFKed3KnYqIt4gS78eUQYNRrkIVMnnplsTcO/SPLyTm5JV+/R1KMVFuwqXLRMneEBSpTnK7Ekhg5OoBjujokyEkAvMWd28J1Kidk6mIZuJiWQhiAQCyQAovz194VYziISbKGYvmQ7kDYEiwfiFKahDk10OMZSdEuIzJk+YGWe7TZJ5O61+Z+zCDK7BhNlBJUUlA8JRluWuSTsT+UDYWubqiQouAzggDnVoKRJUQy3lpDHN8xu7AaMH1jMIPc5bbCTrS1QVSpQjKk+NaUOVq0excbCKzVVgVPVnDtbM+rXFhrFnUmSgeIkgscr3PBUdfQRWa+okJnEpBDi4RckjbxG3WNTpKmxY/usb4fUFYcXSSzKSlTkcWd9oZyp5+cplgGxKvi6MbD7QvkVJUMsrwy8oBys6QTcv72DQSZMtBStThAPgSs6n6iDtraJxm3Tj1+f8Aocl8kSsQlKzZ2Kgv4hu1wRsBB6a9ZBVKUlbfKosfK8JcVxeSlKmlhTkkkga+bQllYqhaCzpWAL+lnHEaUmtfwPhassU/FTMCk5cqhqLC455gPCsWCCpyTZrP92hJT1pWwJDgOT/aCKCZ3k0KSQEp1UAT6ADUniKR+WJx8FompBBU5DpLDYwPRIWcuRJSXuoEsoE7g2sILlUudLLlqH05ir3KQAEiDKSSJQKUOTqXIy8WESlhTnyTpeRc6VBKpROqtNogrZQUwWXHPHlA5npzHkajiz7wBPxApUEhXorboYt7iJcWwpeBKICkrDHY2hfU4TORcgt0izYFPCpIu5BNuLuB5QykzgbR6McUZRTIPJKLo82MlzrE5QGu0XyqwyVM+JAfkWMIK/ssdZSn/lV+sYlgkujUcqfYjp5aeG6xqckPaIquVPlljJI6k294EXMnbBI9Yi012VTsnUkvZDxxMCvpaIQZm81vICOFA/NNJ/fSFQyZ1dBGnTuu/SB1BH8x943llf7Z9jAAppsJkSVJ/ErEyaWCZMs2KuCqO+0GMVKP4HdfhktZASxbl9/OKmVJN7k8m8XPs5j1ROApp0j8ZJ+lfxyxo6ZuqW6+4jrUk9LRJp9vZUULXmCwpQUC4UCQoHkEXEXTBcSm1oEirpvxSRYTR4J0vr3gYH1b1gqs7O0FOszFTVqRYiUSHB3SVJ+L0gaq7RTFJ7unliVL6Bif31gX0dszfLpE87svQUi1KnTVTB8su2byURr6RzNx2dM/gUsrukaBKB4j7Rz2e7NT6pWYgBD3mKv7cmPT8HwSVTpZCfFus/Ef08o0m5daRmVLvZS8D7ALUy6pZ5yAufU7ekXugw+VJTklICR0H5neCjHJjaSRhybIa2qEtClnRIJ/xFNwWsdRQkZlLU5OwN/cxYu0UjPKKDYEM/B10ilYtWzZQlIkLy5W0s5ZtOrmOD1eVwkr6Ov00FKLXljyZNmoUUzfhDFJSB4i9gQbiB8ZE0JAykqmFyghgAOYFr8eWhKJaUBU03UtVwDwkbRVcX7XT1qAmKJyuC1hfy1jknnxq1G2dEME5NOkMq6rIV8TrLeIaJ6DrHWF4a6wVghKiTnGpa7JJ1cjWF2DnvloSQyVKudLAE2fyiy104IKUBfhSCByHSQP31jkhH3Zc5PrwWyS4LiiGv7QBAVLSVFYe5ub6eKKljONT1pYKUE2FjfgnygurRMWo5SALOrc2vCirnS5a+7IUqxLh1F+I66b2SjS6Mp11E1ABmFCQddz0cbRYsHkS0gguFKDFTDTp1vFVGIAKTLQFhRuyhp5wbMVMdKkkktsGDw6aG9nomGTkglKLukObZhldrMAzmI8TwpSxm7wqW1sxSlKT5AFz6xUsLrVId1eLfljDFWJTGct93hNPyidb0witX3aUJXISoIQ1iFDNZ1dTrqN4qVZ2gSF5VI+G1gLcCJMS7UAkypfiW7PcpHPmYQ0uHrJdQe7m97xviysUv6hkcWVOUEpTlTow1L8kAt6CPSuyOH5JSFLlZFXuVNuzkJO4azQpwDs+paE2EoAagAqvt5xc59YiUgJfYBy3TiGkluRHLO/pic4mpaUEpS6mLMTrtFaqsRVKIM50v8ADbc7eHeDqzGc2hypHuesUftR2kysQcyszhJ3Fw8TaU3aCEX0xgcaJWpQU5PNhaFNTjGeaDMUTa4Qx+8V41kyc+c5UqOibejxkiRlUwU/PA6mD22joUUemYHjiJYspQTwRd+ph8vtMRfuweC+3tHl+G1aAW8RID8O35QzoMRWdLcAuzeZMYeXJiVqVf7MPBGT2j0zC+0JmKAUhkGwVfU8w+SsHQvHmdLVtdSSN3SbexiwUuNqSkLABl5mUpPyq/mSdPMR0ej9a2qnK3+z/Y5s3pq3FUWmfKCgxAI6xW8U7NhTmWcp+k6f4htS4oFZS3hUWCv3tBy0x6UZQyq0cj5QZ5nU0/dFlpZXk7xEpZIsn3YR6FU0iV+FaXBirYv2aMvxJClpf6rj9YhPC1tFo5U+xM6x9PvGzNVymIJiL/8AgPqbfnHYQneWPeIlQWu7L0MhZmrmryMD3BUl0KOqVTE6gdLwDWdq/D3VLLTLRwkN/k+ZitTqvOrMoqUesdS1l7JA8zHU5/CJKHyT99MUrMQ55Uf20XzsT2WmT2nTxllbJu8z9E9d4B7CdnDPJnzgO4l66+NQ+UdOfaPW5K0lIy6CzAMzbNtDhC9szOdaR1JkpSAlIAADADQR2Y5zRuLHOYY5MbgKqxWVLWETFZMxZKl+FKjwFGxMA0QY2o5WCmPHMVuqkpbvVsnKDkADkjR1HyeLZX0qVi4u1jFRqjlSUtoAn2F4871WN8uR1YZaorFcmbPngSlAKCVMDu/XmA6TCZkwqeWsBKgmaWdlOHIfVng3DpgK1NaYFuknjcPx+sEf68ZZfKQsE5hfKra20cqjHtnZzktI5oUlCZhlrSGASAocl3tpASFy1q/iKzNchyPFsfSDcSxqWuWxQHNzYOfWK5KnhBJQAH2N42sdvRnl8h2IVAAaXc7DjzheikZlKUxP39I5RVEKKiAXjunIUvO50048o24+BJ0YmleYVDVIFzv0jmbiRBysLbh4FrJ6ySkaPtv5wKJCuIpHGxN2d1MwqU4BNti0SS5c8oOVRSCOXPk+0S4fMyE5w4IhrLqEHwggFQ0O0JxaFzEVBgmSYMyhYOLMX3BO8PqWTlPeJbw7RJJy2PxHfeJfxCSQwYjY7xht+R8rLPRyJipYmqm92SHyAB263AHsYQYrisuUStayU6BVy/QR3WV6yPFZDM769PKKZiipyyAsju8xysPZ+rRLgm9mokFd2pmzCcicozOk626jSBpKFTSVr8R3MdmhATYNfW+8SU4yH833jbko9IstrQWJWVJsOh9OkD0aQ+U6HVoa0kt0Fk5idMpBboRqIk/0sEgpI5Kb+x4jMr00ZTq0wYyyFJF2e+2h0EOZAdYUEBhf4vC3B0u0cS5KyS8lPLsoW6AljDOlkqXLzZSQkgDoeOI55zkvsv8AsbXWwrDgSoovlVqkBwGuFBoPxAhIIQnKCAFAaKva3P6xFSkS1OshRylmLMTzzApxVwA1w5PWMOfFW/uEk2/wF4LiUyVkl5c4zOkerkWvHo8pTpBIYkAtw+0eXYXioCkqTrmF+Do3lHo9LWBUer6C+Gzz/Wfd0FKTHJ4MdZogmiPQOQRY5g1jMlh+U/3EVNRL6faPSFQnqcHClOCz6jrHPlw3uJ0Y8takeFysPveYPtFpwTCZBSL97MIfKolIABBZJAuWBuevnA0mjR/tk/8AGLr2YwdSqcrBKAVskADQak8l9OGiauWkVlpWxrhOM92Ey+5/gXAMsZkpD6kpGXKWN9b6Qsn41No6tilKqdaiPChiBYAhKE3ZravDWTS5BlUuaBmJcLb0sNISdpaWX4TLEyYUvnLubcEizfy2ittIiqbPQZU1KgFJIUk3BFwY6eKhg+JVKEpV+HnLlkOrMxVYfGkfE5a4L6u+r2JWKyu6E53SW01B4IOhGheKp2TcQ8GFHaDBUz5a8vhmlJyrDBWhAGYgsL/nBtHUJmIC0KdJ3/MHgxDiaJxSO5UlKwfmdiOLA9NoPAlpiHDK5VLOFFPmFbpSZazs9spUwcP5tYbiOO0FEQSoXcl4BxfCJlQf4ylyZoUAVkZpCrOnKpgQOhNj5xY1IMyUlRFykP0LXHu8SlBS0ynKto82mgoJ8N+RYiAptUTchy9n09Yt2IYexuIWLohxEf06LLMVhUtSi5iVFCTFg/DAbRvuxG1jSE8wjThfMTJwtMNmjTRvgibyMATh6RtGGjTBxTGmjSRnkxRUUFoVTKEhTjURbMsCzqMEvA4JjU2irze+BcKI8rRF/qE8P4n8wDFqNOOIiXh6TtE3iRRZSnz6iZMISuYrKS7Pb2hwhQy5SC9m/WGE/CEkaQsmhSTlI3t+kRy4nWisMqboJFEFBkl3vxeOF0agQGc/SSHPUEawTSzkk5S6VbH9IPpJRXMbMGSLlr349o42zoE/4AgFVkkXZy8HUM9jeYVFrA3vxBVTLlTP4aXsbru3W+/pBfZ6nQ7rKhkUSgBnuD4nN9+YjKCl06NqWtgtPVnN4lN1ZNvs8EKrmDBTj+UhPuyXhpRUiAqYcz5lWDBRuA5L2a0RYkqQotMQEqToUMkbMdL+UTlik/6x+5G+hcmYxJI15dveIK2mU6ctgQ6iLjoImqJiflWVeYfzMATK85shU/Tjz/SNYPRpPW2KeetjLC5ASobgReMPnaRUsOlRYMPcFnj3cOPhGjycs+UrLTTTHgkiAKKGCYsTOMsRqlxMYyADx9UkgPmTHrOGUQlyJcv6UJB6lrn3ePIMOklU1A7qxWkPbdQ5Me1kRz4V2dGZ9CjFcOWpLIU3Lh3EI/8ASZiGHeTA3DZdPpLjYH0i5ZoimRZwTIqTRU6fEawZkmXLVwUrKS3Rxb+3WFFbiSZimmOJgYF0u+uVRyOHBa7CLjWSWuBAS5lmYDqAIxKF+TcZ/gV4ViplELKwZZUyg4AuHcADVx01i594ktcXYjq+hEVKZgSKjKZyyVJs6QEnK75d38zyYmqsLkSyQKhSNAJallITmayFNZ23CrvoRBFOKCVSJse/EAt+HRUSgcwB8LM7Ahzmby3FjEnZ6qSpKkJTkynMJZ+UTLlPDBecBtmgWdWLowSEFaLvKCcsxFycyWJTMBe5DfdoJw/Gpc9UtaXCroWg6gLug9fEkD/nDvYVoYzqUK1ELp+Dg6Q8aIqialIJJHkSA54jRgrFRgvELZ+HERYMOxkTZxlMn4CrXxBjopJuLcP6Q0m0gO0JU+htNdlAXTkbRH3cXOfhgO0AzcI6Q6FZWymOe5h+rDOkYMP6QqFYg7qC6TC1zHYMAHdVh/mHtNhgfMoOB8vPm9gIJrarKlwXUSAEDz00/bRzZs6h0Wx43ISI7OpT4pq2AuQN+A/PpAFSmTZMsLcaqWQl/Q3+0GTSoqKwokjV/wAhwImpMKzlOZOVKiTm3c7B9rR5U/XZ5yaxI7o4McVcxUunRl5VyFAj2CT+cAVODqUNP7H2MW78HKllX8QgggoYZmPXb8okrqhMxklQ/qUliOtncwR9T6iCfOcb8LX8CcMb+2LPNK2jKQxSokbN/eBpFNUd4Ja5eUMCzHMoG401ePRzgy3eTMSUNfMQb7hmjpOHJGQrUmXP+KWoBhxlVsDfyLxuGRu+Ua/N6/wzTpdM88q8VTLeWxDBiQH9POO6WakhRUU7EOdQOsX6dhNLNClT5bzh8TFSdLOA93hZinZWjEt5YUDlBAJffcH2s0XjHHJIm5tWIZdWlgLgkc/3iNCmJAVf3/ODpOBANZ/OGUjDQPljoXpUiMvUCKnkTSdbcsIZ0+FjcPy8OJND0g6TRniOmGNR6OeeRyE8nDCPhJHlp7QzpJE0fFfqLQ1p6PpDKRSRYmR4eq0MAqORIEc9ydjABKTHOeODMI1Ea7xJ3gA83wqUkzU5cyiFJJuGDEax6skuAYoVDSS5SRLlpygepJ5UdSYulBPCkDpHN6d3Z0Z/AU0DVsxKElatBE+aOKiWlScqg4LW8i4+4jpIFTxztL3YOTKfEE6hwWuCNiDsWdw0JJ+KJmhKkryTLZklTZVOBmADZ0EpY3LPwXHofcIADISGBAZIsDqBwIXTaGUlymTLBOpCEgn2ETcW/JRSS8CigxAAATmQthwyrOSLlt7O9o7xYFaSQhKgB8RBJG7AoOYbHiO6nC5C1BSpKSQG0szvoLGMVhiSCEqWgFrJUwdPw2LszDRoOLFaHJMubKSVsUqANzyNiND1EJMVwhSElcoBZT4kKSlAmgp8QSogfxUOBwoN80VtSqlc4yQha8ijmU6gDz4yWzEEh7av1i3YNV9zLEqdmRl0WoAJIdw6kkpBDtc7QJ34G1Q1op4mS0rHzJB8i1x6F4rfbuhSZSpoz5wkgZWa3iGYakONRcdIcVS+6Cp0oBSSHUkHwk/WCNOvvCKaaqoQtJQrIpAOZTJSWLEZSyklmLhx7wN+AS3ZWOztWpUyRPyspJCVXFk3SrwlIsU5tzp0j1RJBjyTDJYk1GVgqUoHMkpGZILkFJGpSQS4ayTHp+GzHSm/yi/pGcWh5PkNMuI1SYmEbeLEQNVOI4VTCDSIjnIdJGloyxoRGoUCczgNYNq5s0cTQ6khlaL9VCWogB/WOFTClgfEpzlDW825gfEO9Q0zOnMk5rgnoR7E8R4rlVt7PQS+AWhpwsq1ULvc87t66w1qZpCQAwAYAJ15N9v8iK/TVpSgqObKt8qgwSooJB5326QVQqC5hBmBLpBQo/CVj5STyI51y9tKGm/nXZaS+q34JJ1MqYoZUE6uzAW8zE02mOQZlAcuBoDo+56RFUqnS1uWSHcXCgSzEszF3gSfOJNy48m+0YXoccXclb/I1KT8kM2fMkzcvyKuJgDhQH1J36jWGRrkTARMZzooWSfJw6fL7wHhtbLTMCdEu5B6DXzvG8YrJYQUIDnMV5gSdWdy3R4pihxg0uvhjluSVb+Q+RTmZ/DWfFfu5jgmyXyqIOraRBTVYVMMueWIYpUwZTfEDxaJqOuVMlBSFELAdtwRqL2/7hNjcnLMStwSQlYBJFlXGm8W+mEFOL6MKPJuLLlS0EtQdJcQUMJTC/AJ7oBKwcwCtG/dmixSlAx7GKXOCkebkjxk0BIw1IiZNGkbQW0ZFTBCmSBHYTHcZAI5aOFCJI0RABCpDxEZI4goxGYAKeoQZhNcc6UEsCL+f7EClO8ALnZZj8EH0dj+ccGKXGR2TVouwJSWJ8jEpfmBsNqhNQAdYIunyjvTORmiSIkCQY1mBERvl0hgdmQI4MgR2J4O8czOhhARTEAaxylXEaVM2MBzCRpBQWdzqRBch0k7oJSfMtr6vC2nVNphlUozJI0WWzy/6gPiT1AtxBnfq3ESCdCaHYvmYNTrIWEZVWUFyy13cKAHhJfkQbhEpSM0skEJPhIs6FXAbZi6fQQOZZlOqSMyT8Urh/ml8dU77X1JpqxC8q0HoRe2bnyLexjPRpjhEbIjiWqO3jRg08YTGFUQzycpy6taEwRWK+eRqSEuxIa/SFtfJJS5zgPcEEFn0JeziG1XLLBLML228vvARzJV/EcOoAaEB9ib31aPEnF27PRhLWhXKmrQFoSgJlqL5FA5H5QTv5RLPVmkDwg5bZgA4szHr56wx7xRWUCYwy3e7jS3vC+po0fEV5i58IBHqTz00jnnCST47Xx/4WUk3vQsq6JcvKM2dQDsklTaFoe4iZP4eXUAZMyT/DURmdJykjo/5wmmYsuQWSfAT8JJDj0gWqxNCxnIS5ZITchCdAlI9/2YzgzRxRk0nb8Px/krKMptX4NprkrsJWU65tWA4Gh9YPpcLVMBZ1aXzDQwvoZjnwFKdHKthyzRYsPp5CHHfKdVzkCQl+Q7v9oftPJXN/7oWTJx+0D76mkhSc6gTZlEEkjUpbT/ABA9bVl1KcKBYF/l2A9mETYlglOQF5i4IJUrU36cRX0SFd5kCvAovlbgszm+oForPGpVF9fBKMl35LfgtWCzaNzpxFww2bFKwwAbRasOWLR7mGPGCR5mSVybHoMZHEpUdxUwZGRkZABqMjcYYBHBiMxIowFNqwCzwAVVQJ6QLW3QQBfneK1hPbYLYTQH5HhV67H7RYqauTOHgI8t/UR5zTR3HWC4rla/7EXaiq0zQ73jynFSZEwrY92Wz/ynTP5c/wCLuMKxkoIvHVjyWQyQPQFyuLRFNff32iHDsWTMGt4Y5YvdkRUulOqYlkpVoYPEttI1mG4YwwIvw5IjQpeYLTGzAIDXTDiB59K4sIYvHWWAYjScp0tA1XRkkzJTBZBdPyr/AEV19+Q/mSekCrpuLdITVjTozCqjPLSrfRQ4ULEEbXg6EU8mSrvRobTE9NljqPyhvKnuH2jK+Aa8kuWOFiOu8jkqhiQoxUW0eKbiGIWUhdr2u3r5x6BObiK1juFpmA2iGbCp9lceTiyoS8TBUWV4hwdt/OIKmvWkkmwuQb2Mbq+z2UuHccOIBn0cwuGProOescUvTU9I645kRVqlLLqV+kFYdIQ5VMZtGBYDyv8AnEH4SY3hCR94wUUxYZSU6i99i8Y/Ryuyn6lVRcabHJCGTKlAFrnKA4H8x11hHimJylTCtKGzMOhPPAgZeGrWADYcQVJwf6rxdYJPsh7sVsR/jFBYyg5dC9/aG9OpTgjXy2hnKwocQXT4OxcRtelXJMm8+qJcKUBY6xZqHaFVPhph3QU5AvHakc1jOSqCgYDETy1QxE0ZHIMbJgGZHJMczJgEKa/EwNILETYhXBIiqVWJ+I3iPEsQd7xQcU7UATCEMoCxL7jWJSkUjEpKZjXeDMOxaZLPhWUkaEW/bRkZGKOguWHdscyck8Z0t8Vgr9D6wJPqRI8SF5qdRt9conYp1y/lGRkZSpgx5heMkMUqfgjiLrhHaRwAovGRkViyMkWanq0ruk+kEODrGRkUTJGNxGGZGRkaEYUgxvIeY3GQgNMY4WIyMhgBz5ZMLsPmd0vuVfCXMs8DdHo9vONxkYl8mo/AzVGN1jIyNCNCTyXjF04MZGQUAFNwlJ2gWf2eSdo1GQUABP7McQMMCUI1GQqQHacJUNomRhpG0ZGQUgDJOH9IOk0ZG0ZGQxB8mUOIkKIyMgAxSIyUu7RkZABPngWorwIyMhMYjrsVJ3hBW4h1jIyMSZpI867T9p85MqUbXCljfonp1hBLIbj0jIyJs6Ej/9k=',
                width: 500, // Image width
                height: 250, // Image height
                fit: BoxFit.cover, // Ensure the image does not stretch or distort
              ),
            ),
            SizedBox(height: 20), // Space between the image and text
            // Text describing the steps

            SizedBox(height: 20), // Space between image and description

            // Food description
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'ข้าวแต๋น เป็นขนมพื้นบ้านของไทยที่มีต้นกำเนิดจากภาคเหนือ มีลักษณะเป็นข้าวพองแผ่นกลม ราดด้วยน้ำอ้อยหรือน้ำตาลเคี่ยวจนกรอบและหอม ข้าวแต๋นมักมีรสหวานกรอบ นิยมรับประทานเป็นของว่าง หรือของฝากจากภาคเหนือ',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black54,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            

            // Like and Dislike Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Like button
                IconButton(
                  icon: Icon(Icons.sentiment_very_satisfied, color: Colors.blue),
                  onPressed: () {
                    setState(() {
                      likeCount++;
                    });
                  },
                ),
                Text(
                  '$likeCount Likes',
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 20), // Space between buttons

                // Dislike button
                IconButton(
                  icon: Icon(Icons.sentiment_very_dissatisfied, color: Colors.red),
                  onPressed: () {
                    setState(() {
                      dislikeCount++;
                    });
                  },
                ),
                Text(
                  '$dislikeCount Dislikes',
                  style: TextStyle(fontSize: 16),
                ),
              ],
            ),
            SizedBox(height: 20), // Space between buttons and the next content

            // Center the "Open Page 1" button
            Center(
              child: ElevatedButton(
                child: Text('เปิดหน้าที่ 1'),
                onPressed: () {
                  Navigator.pushNamed(context, '/');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Method for creating step text
  Widget _buildStep(int stepNumber, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        children: [
          Text(
            '$stepNumber.',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ),
        ],
      ),
    );
  }
}